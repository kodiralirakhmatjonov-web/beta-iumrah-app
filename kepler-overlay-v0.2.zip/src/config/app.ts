export const APP_CONFIG = {
  name: 'iumrah',
  channel: 'beta',
  apiBaseUrl: 'https://api.iumrah.com',
} as const;
