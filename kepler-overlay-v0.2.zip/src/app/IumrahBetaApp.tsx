import React from 'react';
import {
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import {StatusPill} from '../components/StatusPill';
import {APP_CONFIG} from '../config/app';
import {colors, radii, spacing} from '../theme/tokens';

const foundationItems = [
  ['Mobile', 'React Native 0.87 + TypeScript'],
  ['Build', 'GitHub Actions · iOS + Android'],
  ['Backend', 'Cloudflare + Gemini package engine'],
] as const;

export function IumrahBetaApp(): React.JSX.Element {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" />
      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Math.max(insets.top, spacing.lg),
            paddingBottom: insets.bottom + spacing.xl,
          },
        ]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.wordmark}>{APP_CONFIG.name}</Text>
          <StatusPill label="Foundation ready" />
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>NEW CLIENT APP</Text>
          <Text style={styles.title}>Your Umrah.{`\n`}Built around you.</Text>
          <Text style={styles.subtitle}>
            Clean native foundation for the new iumrah beta. The Umrah package generator will be built on top of this shell.
          </Text>
        </View>

        <View style={styles.card}>
          {foundationItems.map(([label, value], index) => (
            <View
              key={label}
              style={[
                styles.row,
                index !== foundationItems.length - 1 && styles.rowBorder,
              ]}>
              <Text style={styles.rowLabel}>{label}</Text>
              <Text style={styles.rowValue}>{value}</Text>
            </View>
          ))}
        </View>

        <View style={styles.nextCard}>
          <Text style={styles.nextLabel}>NEXT</Text>
          <Text style={styles.nextTitle}>Umrah Generator</Text>
          <Text style={styles.nextText}>
            Departure · dates · pilgrims · Economy / Comfort / Signature · live AI search.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    backgroundColor: colors.background,
    flex: 1,
  },
  content: {
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 64,
  },
  wordmark: {
    color: colors.text,
    fontSize: 25,
    fontWeight: '700',
    letterSpacing: -1.2,
  },
  hero: {
    marginBottom: spacing.xl,
  },
  eyebrow: {
    color: colors.secondaryText,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.2,
    marginBottom: spacing.sm,
  },
  title: {
    color: colors.text,
    fontSize: 46,
    fontWeight: '700',
    letterSpacing: -2.3,
    lineHeight: 49,
  },
  subtitle: {
    color: colors.secondaryText,
    fontSize: 17,
    letterSpacing: -0.35,
    lineHeight: 25,
    marginTop: spacing.md,
    maxWidth: 520,
  },
  card: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderRadius: radii.large,
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.md,
    overflow: 'hidden',
    paddingHorizontal: 18,
  },
  row: {
    gap: 14,
    paddingVertical: 18,
  },
  rowBorder: {
    borderBottomColor: colors.border,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  rowLabel: {
    color: colors.secondaryText,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  rowValue: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '600',
    letterSpacing: -0.35,
  },
  nextCard: {
    backgroundColor: colors.text,
    borderRadius: radii.large,
    padding: spacing.lg,
  },
  nextLabel: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.25,
  },
  nextTitle: {
    color: '#FFFFFF',
    fontSize: 25,
    fontWeight: '700',
    letterSpacing: -0.8,
    marginTop: 7,
  },
  nextText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 15,
    lineHeight: 22,
    marginTop: 8,
  },
});
