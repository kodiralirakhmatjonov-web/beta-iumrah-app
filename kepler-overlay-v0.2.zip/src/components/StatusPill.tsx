import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

import {colors, radii} from '../theme/tokens';

type StatusPillProps = {
  label: string;
};

export function StatusPill({label}: StatusPillProps): React.JSX.Element {
  return (
    <View style={styles.container}>
      <View style={styles.dot} />
      <Text style={styles.text}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: '#EEF7F1',
    borderRadius: radii.pill,
    flexDirection: 'row',
    gap: 7,
    paddingHorizontal: 11,
    paddingVertical: 7,
  },
  dot: {
    backgroundColor: colors.success,
    borderRadius: 4,
    height: 7,
    width: 7,
  },
  text: {
    color: colors.success,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: -0.15,
  },
});
