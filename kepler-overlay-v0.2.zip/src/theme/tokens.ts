export const colors = {
  background: '#F5F5F7',
  surface: '#FFFFFF',
  text: '#111113',
  secondaryText: '#68686F',
  border: 'rgba(17, 17, 19, 0.08)',
  accent: '#111113',
  success: '#277A4B',
} as const;

export const radii = {
  medium: 20,
  large: 28,
  pill: 999,
} as const;

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 24,
  xl: 32,
} as const;
