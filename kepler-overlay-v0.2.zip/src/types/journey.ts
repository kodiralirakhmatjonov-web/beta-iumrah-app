export type PackageTier = 'economy' | 'comfort' | 'signature';

export type JourneyStatus =
  | 'draft'
  | 'generated'
  | 'verifying'
  | 'verified'
  | 'confirmed';

export type JourneySummary = {
  id: string;
  status: JourneyStatus;
  tier: PackageTier;
  pilgrims: number;
  departureCity: string;
};
