# kepler-mobile

Public codename repository for the new iumrah client application.

## Foundation

- React Native 0.87.0
- React 19.2.3
- TypeScript
- Native iOS + Android projects
- GitHub Actions builds

No production secrets, Gemini keys, Cloudflare credentials, private pricing logic, or customer data belong in this repository.
