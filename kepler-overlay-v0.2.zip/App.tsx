import React from 'react';
import {SafeAreaProvider} from 'react-native-safe-area-context';

import {IumrahBetaApp} from './src/app/IumrahBetaApp';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaProvider>
      <IumrahBetaApp />
    </SafeAreaProvider>
  );
}
