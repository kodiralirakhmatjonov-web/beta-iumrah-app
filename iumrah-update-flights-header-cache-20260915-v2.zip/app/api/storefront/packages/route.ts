import { NextRequest, NextResponse } from "next/server";
import {
  buildPricedStorefrontPackages,
  hotelFirstPackagesFromFlightFirst,
  loadStorefrontCandidatePackages,
  STORE_ORIGINS,
  type StorefrontPackageEntryMode,
} from "@/lib/storefront-packages";
import {
  readStorefrontCache,
  scheduleStorefrontRefresh,
  writeStorefrontCache,
} from "@/lib/storefront-cache";

export const dynamic = "force-dynamic";

const FULL_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const WARMING_CACHE_TTL_MS = 15 * 60 * 1000;
const MAX_STORE_PACKAGES = 60;
let refreshInFlight: Promise<void> | null = null;

function parseMode(value: string | null): StorefrontPackageEntryMode {
  return value === "hotel-first" ? "hotel-first" : "flight-first";
}

function parseLimit(value: string | null) {
  const parsed = Number.parseInt(value ?? "", 10);
  if (!Number.isFinite(parsed)) return MAX_STORE_PACKAGES;
  return Math.max(1, Math.min(MAX_STORE_PACKAGES, parsed));
}

function parseOrigins(value: string | null) {
  if (!value) return Array.from(STORE_ORIGINS);
  const allowed = new Set<string>(STORE_ORIGINS);
  const parsed = value
    .split(",")
    .map((item) => item.trim().toUpperCase())
    .filter((item) => allowed.has(item));
  return parsed.length ? parsed : Array.from(STORE_ORIGINS);
}

function packageApiBase(request: NextRequest) {
  const origin = request.nextUrl.origin;
  const hostname = request.nextUrl.hostname;
  if (hostname === "localhost" || hostname === "127.0.0.1") return "https://iumrah.app";
  return origin;
}

async function refreshDailyCache(baseUrl: string) {
  const flightFirst = await buildPricedStorefrontPackages({
    maxPackages: MAX_STORE_PACKAGES,
    origins: Array.from(STORE_ORIGINS),
    baseUrl,
  });

  if (!flightFirst.length) return;

  const hotelFirst = hotelFirstPackagesFromFlightFirst(flightFirst);
  const flightFirstComplete = flightFirst.every((item) => item.status === "ready");
  const hotelFirstComplete = hotelFirst.length > 0 && hotelFirst.every((item) => item.status === "ready");
  await Promise.all([
    writeStorefrontCache({
      mode: "flight-first",
      items: flightFirst,
      isComplete: flightFirstComplete,
      ttlMs: flightFirstComplete ? FULL_CACHE_TTL_MS : WARMING_CACHE_TTL_MS,
    }),
    writeStorefrontCache({
      mode: "hotel-first",
      items: hotelFirst,
      isComplete: hotelFirstComplete,
      ttlMs: hotelFirstComplete ? FULL_CACHE_TTL_MS : WARMING_CACHE_TTL_MS,
    }),
  ]);
}

function refreshOnce(baseUrl: string) {
  if (!refreshInFlight) {
    refreshInFlight = refreshDailyCache(baseUrl).finally(() => {
      refreshInFlight = null;
    });
  }
  return refreshInFlight;
}

export async function GET(request: NextRequest) {
  const mode = parseMode(request.nextUrl.searchParams.get("mode"));
  const limit = parseLimit(request.nextUrl.searchParams.get("limit"));
  const origins = parseOrigins(request.nextUrl.searchParams.get("origins"));
  const baseUrl = packageApiBase(request);

  const cached = await readStorefrontCache(mode);
  const filteredCached = cached?.items.filter((item) => origins.includes(item.originCode)).slice(0, limit) ?? [];

  if (cached?.isComplete && !cached.isExpired && filteredCached.length) {
    return NextResponse.json({
      ok: true,
      cacheState: "ready",
      generatedAt: cached.generatedAt,
      expiresAt: cached.expiresAt,
      items: filteredCached,
    });
  }

  if (cached?.isComplete && filteredCached.length) {
    scheduleStorefrontRefresh(refreshOnce(baseUrl));
    return NextResponse.json({
      ok: true,
      cacheState: "stale-refreshing",
      generatedAt: cached.generatedAt,
      expiresAt: cached.expiresAt,
      items: filteredCached,
    });
  }

  if (filteredCached.length) {
    scheduleStorefrontRefresh(refreshOnce(baseUrl));
    return NextResponse.json({
      ok: true,
      cacheState: "warming",
      generatedAt: cached?.generatedAt ?? null,
      expiresAt: cached?.expiresAt ?? null,
      items: filteredCached,
    });
  }

  const candidates = await loadStorefrontCandidatePackages({
    maxPackages: MAX_STORE_PACKAGES,
    origins: Array.from(STORE_ORIGINS),
    baseUrl,
  });
  const hotelCandidates = hotelFirstPackagesFromFlightFirst(candidates);

  if (candidates.length) {
    await Promise.all([
      writeStorefrontCache({
        mode: "flight-first",
        items: candidates,
        isComplete: false,
        ttlMs: WARMING_CACHE_TTL_MS,
      }),
      writeStorefrontCache({
        mode: "hotel-first",
        items: hotelCandidates,
        isComplete: false,
        ttlMs: WARMING_CACHE_TTL_MS,
      }),
    ]);
  }

  scheduleStorefrontRefresh(refreshOnce(baseUrl));

  const responseItems = (mode === "hotel-first" ? hotelCandidates : candidates)
    .filter((item) => origins.includes(item.originCode))
    .slice(0, limit);

  return NextResponse.json({
    ok: true,
    cacheState: "warming",
    generatedAt: null,
    expiresAt: null,
    items: responseItems,
  });
}
