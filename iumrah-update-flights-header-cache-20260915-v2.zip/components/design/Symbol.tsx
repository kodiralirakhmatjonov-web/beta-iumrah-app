import type { CSSProperties } from "react";

export type SymbolName =
  | "sparkles"
  | "airplane"
  | "bed"
  | "car"
  | "train"
  | "map"
  | "calendar"
  | "person"
  | "heart"
  | "message"
  | "location"
  | "chevron"
  | "plus"
  | "minus"
  | "check"
  | "shield"
  | "phone"
  | "globe"
  | "arrowRight"
  | "chevronRight"
  | "chevronDown"
  | "menu"
  | "close"
  | "ellipsis";

const codepoints: Record<SymbolName, number> = {
  sparkles: 0xf7e8,
  airplane: 0xf4d4,
  bed: 0xf589,
  car: 0xf36f,
  train: 0xf36d,
  map: 0xf703,
  calendar: 0xf5b0,
  person: 0xf74d,
  heart: 0xf443,
  message: 0xf5a6,
  location: 0xf6f1,
  chevron: 0xf3d1,
  plus: 0xf489,
  minus: 0xf463,
  check: 0xf3fd,
  shield: 0xf4c7,
  phone: 0xf4b8,
  globe: 0xf68d,
  arrowRight: 0xf50a,
  chevronRight: 0xf3d3,
  chevronDown: 0xf358,
  menu: 0xf6e1,
  close: 0xf404,
  ellipsis: 0xf46a,
};

export function Symbol({ name, size = 20, className }: { name: SymbolName; size?: number; className?: string }) {
  const style: CSSProperties = { fontSize: size, width: size, height: size };
  return (
    <span aria-hidden="true" className={className ? `ui-symbol ${className}` : "ui-symbol"} style={style}>
      {String.fromCodePoint(codepoints[name])}
    </span>
  );
}
