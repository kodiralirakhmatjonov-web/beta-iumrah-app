import { getCloudflareContext } from "@opennextjs/cloudflare";
import type { StorefrontPackage, StorefrontPackageEntryMode } from "@/lib/storefront-packages";

type D1Value = string | number | null;

type D1PreparedStatement = {
  bind: (...values: D1Value[]) => D1PreparedStatement;
  first: <T = Record<string, unknown>>() => Promise<T | null>;
  run: () => Promise<unknown>;
};

type D1Database = {
  prepare: (query: string) => D1PreparedStatement;
  batch: (statements: D1PreparedStatement[]) => Promise<unknown[]>;
};

type CloudflareStorefrontEnv = {
  DB?: D1Database;
};

type CacheRow = {
  cache_key: string;
  payload_json: string;
  generated_at: string;
  expires_at: string;
  item_count: number;
  is_complete: number;
};

export type StorefrontCacheRecord = {
  items: StorefrontPackage[];
  generatedAt: string;
  expiresAt: string;
  isComplete: boolean;
  isExpired: boolean;
};

let schemaPromise: Promise<void> | null = null;

function cacheKey(mode: StorefrontPackageEntryMode) {
  return `storefront:${mode}:v3`;
}

export function getStorefrontDb(): D1Database | null {
  try {
    const env = getCloudflareContext().env as unknown as CloudflareStorefrontEnv;
    return env.DB ?? null;
  } catch {
    return null;
  }
}

export async function ensureStorefrontCacheSchema(db: D1Database) {
  if (!schemaPromise) {
    schemaPromise = db.batch([
      db.prepare(`CREATE TABLE IF NOT EXISTS storefront_package_cache (
        cache_key TEXT PRIMARY KEY,
        payload_json TEXT NOT NULL,
        generated_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        item_count INTEGER NOT NULL DEFAULT 0,
        is_complete INTEGER NOT NULL DEFAULT 0
      )`),
      db.prepare("CREATE INDEX IF NOT EXISTS idx_storefront_package_cache_expiry ON storefront_package_cache(expires_at)"),
    ]).then(() => undefined).catch((error) => {
      schemaPromise = null;
      throw error;
    });
  }
  await schemaPromise;
}

export async function readStorefrontCache(mode: StorefrontPackageEntryMode): Promise<StorefrontCacheRecord | null> {
  const db = getStorefrontDb();
  if (!db) return null;
  await ensureStorefrontCacheSchema(db);

  const row = await db.prepare(`SELECT cache_key, payload_json, generated_at, expires_at, item_count, is_complete
    FROM storefront_package_cache WHERE cache_key = ? LIMIT 1`)
    .bind(cacheKey(mode))
    .first<CacheRow>();
  if (!row) return null;

  try {
    const items = JSON.parse(row.payload_json) as StorefrontPackage[];
    if (!Array.isArray(items)) return null;
    const expiresAtMs = Date.parse(row.expires_at);
    return {
      items,
      generatedAt: row.generated_at,
      expiresAt: row.expires_at,
      isComplete: row.is_complete === 1,
      isExpired: !Number.isFinite(expiresAtMs) || expiresAtMs <= Date.now(),
    };
  } catch {
    return null;
  }
}

export async function writeStorefrontCache(input: {
  mode: StorefrontPackageEntryMode;
  items: StorefrontPackage[];
  isComplete: boolean;
  ttlMs: number;
}) {
  const db = getStorefrontDb();
  if (!db) return false;
  await ensureStorefrontCacheSchema(db);

  const generatedAt = new Date().toISOString();
  const expiresAt = new Date(Date.now() + input.ttlMs).toISOString();
  await db.prepare(`INSERT INTO storefront_package_cache (
      cache_key, payload_json, generated_at, expires_at, item_count, is_complete
    ) VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(cache_key) DO UPDATE SET
      payload_json = excluded.payload_json,
      generated_at = excluded.generated_at,
      expires_at = excluded.expires_at,
      item_count = excluded.item_count,
      is_complete = excluded.is_complete`)
    .bind(
      cacheKey(input.mode),
      JSON.stringify(input.items),
      generatedAt,
      expiresAt,
      input.items.length,
      input.isComplete ? 1 : 0,
    )
    .run();
  return true;
}

export function scheduleStorefrontRefresh(promise: Promise<unknown>) {
  try {
    const context = getCloudflareContext() as unknown as { ctx?: { waitUntil?: (value: Promise<unknown>) => void } };
    if (context.ctx?.waitUntil) {
      context.ctx.waitUntil(promise);
      return;
    }
  } catch {
    // Local/dev fallback below.
  }

  void promise.catch(() => undefined);
}
