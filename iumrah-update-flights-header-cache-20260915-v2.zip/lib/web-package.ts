export type PackageTier = "economy" | "standard" | "comfort" | "luxury";

export type StorefrontLeg = {
  airline: string;
  flight_number: string;
  airline_code: string;
  origin: string;
  destination: string;
  departure_at: string;
  arrival_at: string;
  duration_minutes: number;
  stops: number;
  cabin_class: string;
};

export type CuratedFlightRecommendation = {
  id: string;
  outboundDate: string;
  inboundDate: string | null;
  cabinClass: string;
  airlineCodes: string[];
  airlineNames: string[];
  flightNumbers: string[];
  observedAt: string;
  outbound: StorefrontLeg;
  inbound: StorefrontLeg | null;
  nonstop: boolean;
  recommendationLabel: string;
  offerType: string | null;
  journeyRole: string | null;
};

export type StorefrontFlightOption = {
  id: string;
  kind: string;
  priority: number;
  currency: string;
  travelerCount: number;
  totalFare: number;
  perTravelerFare: number;
  observedAt: string;
  outbound: StorefrontLeg;
  inbound: StorefrontLeg | null;
  baggage?: { carryOn?: number | null; checked?: number | null } | null;
};

export type StorefrontFlightBoardResponse = {
  ok: boolean;
  origin: string;
  generatedAt: string;
  options: StorefrontFlightOption[];
};

export type PublishedFlightSelection = {
  completeID: string | null;
  outboundID: string | null;
  returnID: string | null;
};

export type DirectJourneyOption = {
  id: string;
  providerItineraryId: string;
  outboundOfferId: string;
  inboundOfferId: string;
  outbound: StorefrontLeg;
  inbound: StorefrontLeg;
  currency: string;
  observedAt: string;
};

export type PrimaryHotelResolution = {
  ok: boolean;
  hotelId: string;
  roomId: string | null;
  tier?: string | null;
  stars: number;
  city: string;
  pricingMode?: string | null;
};

export type HotelSummary = {
  id: string;
  name: string;
  city: string;
  country: string;
  stars: number | null;
  rating: number | null;
  reviewCount: number | null;
  address: string;
  description: string;
  checkIn: string | null;
  checkOut: string | null;
  status: string;
  amenities: string[];
  images: Array<{ id: string; url: string; isCover: boolean; position: number }>;
  rooms: Array<{ id: string; name: string; maxGuests: number | null; beds: string | null }>;
};

export type RoomCategory = { id: string; displayName: string; maxGuests: number; category: string };

export type PackageQuote = {
  totalPackagePrice: number;
  pricePerPerson: number;
  currency: string;
  isEstimated: boolean;
  quoteId: string;
  quoteProof: string;
};

export type TravelerSelection = {
  adults: number;
  children: number;
  infants: number;
  rooms: number;
};

export type MealSelection = {
  makkahLunch: boolean;
  makkahDinner: boolean;
  madinahDinner: boolean;
};

export type StayPlan = {
  startDate: string;
  endDate: string;
  totalNights: number;
  totalDays: number;
  makkahNights: number;
  madinahNights: number;
  makkahCheckIn: string;
  makkahCheckOut: string;
  madinahCheckIn: string;
  madinahCheckOut: string;
};

export type WebPackageDraft = {
  version: 1;
  createdAt: string;
  originCode: string;
  tier: PackageTier;
  travelers: TravelerSelection;
  journey: DirectJourneyOption;
  stay: StayPlan;
  meals: MealSelection;
  transferVehicle: "malibu" | "carnival" | "yukon" | null;
  haramainEnabled: boolean;
  haramainFareClass: "economy" | "business";
  haramainTicketCount: number;
  makkahHotel: HotelSummary;
  madinahHotel: HotelSummary;
  makkahRoomId: string | null;
  madinahRoomId: string | null;
  quote: PackageQuote;
};

export type BookingContactProfile = {
  firstName: string;
  lastName: string;
  telegram: string;
  whatsapp: string;
};

export type GeneratorTrace = {
  quoteId: string;
  outbound: Record<string, unknown>;
  inbound: Record<string, unknown>;
  makkahHotel: Record<string, unknown>;
  madinahHotel: Record<string, unknown>;
};

export type StoredWebBooking = {
  id: string;
  accessToken: string;
  createdAt: string;
  draft: Omit<WebPackageDraft, "quote"> & { quote: Omit<PackageQuote, "quoteProof"> };
  profile?: BookingContactProfile;
  generatorTrace?: GeneratorTrace;
  pendingQuoteProof?: string;
};

export const PACKAGE_DRAFT_KEY = "iumrah.web.package-draft.v1";
export const BOOKING_KEY = "iumrah.web.booking.v1";

const TIER_STARS: Record<PackageTier, number> = {
  economy: 2,
  standard: 3,
  comfort: 4,
  luxury: 5,
};

export function hotelStarsForTier(tier: PackageTier) {
  return TIER_STARS[tier];
}

function dateOnly(value: string) {
  return value.slice(0, 10);
}

function utcDate(value: string) {
  return new Date(`${dateOnly(value)}T00:00:00Z`);
}

function addDays(value: string, days: number) {
  const date = utcDate(value);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

export function nightsBetween(start: string, end: string) {
  const ms = utcDate(end).getTime() - utcDate(start).getTime();
  return Math.max(1, Math.round(ms / 86_400_000));
}

export function stayPlanForJourney(journey: DirectJourneyOption): StayPlan {
  const startDate = dateOnly(journey.outbound.arrival_at || journey.outbound.departure_at);
  const endDate = dateOnly(journey.inbound.departure_at);
  const totalNights = nightsBetween(startDate, endDate);
  const makkahNights = totalNights > 1 ? Math.max(1, Math.min(totalNights - 1, Math.ceil(totalNights * 0.6))) : totalNights;
  const madinahNights = totalNights > 1 ? Math.max(1, totalNights - makkahNights) : 0;
  const madinahCheckIn = startDate;
  const madinahCheckOut = addDays(startDate, madinahNights);
  return {
    startDate,
    endDate,
    totalNights,
    totalDays: totalNights + 1,
    makkahNights,
    madinahNights,
    makkahCheckIn: madinahCheckOut,
    makkahCheckOut: endDate,
    madinahCheckIn,
    madinahCheckOut,
  };
}

export function isOneWayRecommendation(item: CuratedFlightRecommendation) {
  return (item.offerType ?? (item.inbound ? "paired_one_way" : "one_way")) === "one_way";
}

export function recommendationRole(item: CuratedFlightRecommendation) {
  if (item.journeyRole) return item.journeyRole;
  return isOneWayRecommendation(item) ? "outbound" : "complete";
}

function futureDate(days: number) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function apiUrl(path: string, baseUrl?: string) {
  if (!baseUrl) return path;
  return new URL(path, baseUrl).toString();
}

export async function fetchCuratedRecommendations(origin: string, baseUrl?: string): Promise<CuratedFlightRecommendation[]> {
  const params = new URLSearchParams({
    umrah_origin: origin.toUpperCase(),
    from: futureDate(0),
    to: futureDate(365),
  });
  const response = await fetch(apiUrl(`/api/package/flights/recommendations?${params.toString()}`, baseUrl), { cache: "no-store" });
  const body = await response.json() as { ok?: boolean; recommendations?: CuratedFlightRecommendation[]; error?: string };
  if (!response.ok || !body.ok) throw new Error(body.error || "FLIGHTS_UNAVAILABLE");
  return (body.recommendations ?? []).filter((item) => item.nonstop);
}

export async function fetchStorefrontFlightBoard(origin = "TAS", baseUrl?: string): Promise<StorefrontFlightBoardResponse> {
  const params = new URLSearchParams({ origin: origin.toUpperCase() });
  const response = await fetch(apiUrl(`/api/package/storefront/flights?${params.toString()}`, baseUrl), { cache: "no-store" });
  const body = await response.json() as StorefrontFlightBoardResponse & { error?: string };
  if (!response.ok || !body.ok || !Array.isArray(body.options)) {
    throw new Error(body.error || "STOREFRONT_FLIGHTS_UNAVAILABLE");
  }
  return {
    ...body,
    options: body.options.filter((item) => item.outbound?.stops === 0 && (item.inbound?.stops ?? 0) === 0),
  };
}


export function publishedFlightGroups(recommendations: CuratedFlightRecommendation[], origin: string) {
  const code = origin.toUpperCase();
  const outbound = recommendations
    .filter((item) => isOneWayRecommendation(item) && recommendationRole(item) === "outbound" && item.outbound.origin === code && item.outbound.destination === "MED")
    .sort((a, b) => a.outboundDate.localeCompare(b.outboundDate));
  const returns = recommendations
    .filter((item) => isOneWayRecommendation(item) && recommendationRole(item) === "return" && item.outbound.origin === "JED" && item.outbound.destination === code)
    .sort((a, b) => a.outboundDate.localeCompare(b.outboundDate));
  const complete = recommendations
    .filter((item) => item.inbound && recommendationRole(item) === "complete" && item.outbound.origin === code && item.outbound.destination === "MED" && item.inbound.origin === "JED" && item.inbound.destination === code)
    .sort((a, b) => a.outboundDate.localeCompare(b.outboundDate));
  return { outbound, returns, complete };
}

type ResolvedLeg = {
  id: string;
  airline: string;
  flightNumber: string;
  airlineCode: string | null;
  origin: string;
  destination: string;
  departureAt: string;
  arrivalAt: string;
  durationMinutes: number;
  cabinClass: string | null;
};

type ResolveResponse = {
  ok: boolean;
  resolvedAt: string;
  currency: string;
  totalFare: number;
  providerItineraryID: string;
  sourceName: string;
  outbound: ResolvedLeg;
  inbound: ResolvedLeg;
  error?: string;
};

function publicLeg(leg: ResolvedLeg): StorefrontLeg {
  return {
    airline: leg.airline,
    flight_number: leg.flightNumber,
    airline_code: leg.airlineCode ?? "",
    origin: leg.origin,
    destination: leg.destination,
    departure_at: leg.departureAt,
    arrival_at: leg.arrivalAt,
    duration_minutes: leg.durationMinutes,
    stops: 0,
    cabin_class: leg.cabinClass ?? "economy",
  };
}

export async function resolvePublishedSelection(input: {
  selection: PublishedFlightSelection;
  travelerCount: number;
  origin: string;
}, baseUrl?: string): Promise<DirectJourneyOption> {
  const response = await fetch(apiUrl("/api/package/flights/recommendations/resolve", baseUrl), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      completeID: input.selection.completeID,
      outboundID: input.selection.outboundID,
      returnID: input.selection.returnID,
      travelerCount: input.travelerCount,
      origin: input.origin.toUpperCase(),
      outboundDestination: "MED",
      returnOrigin: "JED",
      returnDestination: input.origin.toUpperCase(),
    }),
  });
  const body = await response.json() as ResolveResponse;
  if (!response.ok || !body.ok) throw new Error(body.error || "FLIGHT_SELECTION_UNAVAILABLE");
  return {
    id: body.providerItineraryID,
    providerItineraryId: body.providerItineraryID,
    outboundOfferId: input.selection.completeID ?? input.selection.outboundID ?? body.outbound.id,
    inboundOfferId: input.selection.completeID ?? input.selection.returnID ?? body.inbound.id,
    outbound: publicLeg(body.outbound),
    inbound: publicLeg(body.inbound),
    currency: body.currency,
    observedAt: body.resolvedAt,
  };
}

export async function fetchPrimaryHotel(tier: PackageTier, city: "Makkah" | "Madinah", baseUrl?: string) {
  const stars = hotelStarsForTier(tier);
  const response = await fetch(apiUrl(`/api/package/primary-hotel?tier=${tier}&stars=${stars}&city=${encodeURIComponent(city)}`, baseUrl), { cache: "no-store" });
  const body = await response.json() as PrimaryHotelResolution & { error?: string };
  if (!response.ok || !body.ok) throw new Error(body.error || "HOTEL_UNAVAILABLE");
  return body;
}

export async function fetchHotelDetail(id: string, baseUrl?: string): Promise<HotelSummary> {
  const response = await fetch(apiUrl(`/api/catalog/hotels/${encodeURIComponent(id)}`, baseUrl), { cache: "no-store" });
  const body = await response.json() as { ok?: boolean; hotel?: HotelSummary; error?: string };
  if (!response.ok || !body.hotel) throw new Error(body.error || "HOTEL_DETAIL_UNAVAILABLE");
  return body.hotel;
}

export async function fetchRoomCategories(hotelId: string, baseUrl?: string): Promise<RoomCategory[]> {
  const response = await fetch(apiUrl(`/api/package/hotel/${encodeURIComponent(hotelId)}/room-categories`, baseUrl), { cache: "no-store" });
  const body = await response.json() as { ok?: boolean; categories?: RoomCategory[]; error?: string };
  if (!response.ok || !body.ok) throw new Error(body.error || "ROOMS_UNAVAILABLE");
  return body.categories ?? [];
}

export function preferredRoomId(categories: RoomCategory[], travelers: TravelerSelection): string | null {
  const perRoom = Math.ceil((travelers.adults + travelers.children) / Math.max(1, travelers.rooms));
  const sorted = [...categories].filter((item) => item.maxGuests >= perRoom).sort((a, b) => a.maxGuests - b.maxGuests);
  return sorted[0]?.id ?? categories[0]?.id ?? null;
}

export async function resolveHotelForTier(
  tier: PackageTier,
  city: "Makkah" | "Madinah",
  travelers: TravelerSelection,
  baseUrl?: string,
) {
  const primary = await fetchPrimaryHotel(tier, city, baseUrl);
  const [hotel, categories] = await Promise.all([
    fetchHotelDetail(primary.hotelId, baseUrl),
    fetchRoomCategories(primary.hotelId, baseUrl),
  ]);
  return {
    hotel,
    roomId: preferredRoomId(categories, travelers) ?? primary.roomId,
  };
}

export async function resolveHotelsForTier(tier: PackageTier, travelers: TravelerSelection, baseUrl?: string) {
  const [makkah, madinah] = await Promise.all([
    resolveHotelForTier(tier, "Makkah", travelers, baseUrl),
    resolveHotelForTier(tier, "Madinah", travelers, baseUrl),
  ]);
  return {
    makkahHotel: makkah.hotel,
    madinahHotel: madinah.hotel,
    makkahRoomId: makkah.roomId,
    madinahRoomId: madinah.roomId,
  };
}

export async function requestPackageQuote(input: {
  tier: PackageTier;
  travelers: TravelerSelection;
  journey: DirectJourneyOption;
  stay: StayPlan;
  meals: MealSelection;
  transferVehicle: "malibu" | "carnival" | "yukon" | null;
  haramainEnabled: boolean;
  haramainFareClass: "economy" | "business";
  haramainTicketCount: number;
  makkahHotelId: string;
  makkahRoomId: string | null;
  madinahHotelId: string | null;
  madinahRoomId: string | null;
}, baseUrl?: string): Promise<PackageQuote> {
  const includeMadinah = input.stay.madinahNights > 0 && Boolean(input.madinahHotelId);
  const body = {
    tier: input.tier,
    tripType: "roundTrip",
    includeMadinah,
    travelers: input.travelers,
    meals: input.meals,
    transferVehicle: input.transferVehicle,
    haramain: {
      enabled: input.haramainEnabled,
      fareClass: input.haramainFareClass,
      ticketCount: input.haramainTicketCount,
    },
    flight: {
      providerItineraryId: input.journey.providerItineraryId,
      cabinClass: "economy",
      infantsInSeat: input.travelers.infants,
      infantsOnLap: 0,
      legs: [
        { origin: input.journey.outbound.origin, destination: input.journey.outbound.destination, departureDate: dateOnly(input.journey.outbound.departure_at) },
        { origin: input.journey.inbound.origin, destination: input.journey.inbound.destination, departureDate: dateOnly(input.journey.inbound.departure_at) },
      ],
    },
    hotels: {
      makkah: { hotelId: input.makkahHotelId, roomId: input.makkahRoomId, nights: input.stay.makkahNights },
      ...(includeMadinah && input.madinahHotelId
        ? { madinah: { hotelId: input.madinahHotelId, roomId: input.madinahRoomId, nights: input.stay.madinahNights } }
        : {}),
    },
  };
  const response = await fetch(apiUrl("/api/package/quote", baseUrl), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const result = await response.json() as { ok?: boolean; quote?: PackageQuote; error?: string };
  if (!response.ok || !result.ok || !result.quote) throw new Error(result.error || "QUOTE_UNAVAILABLE");
  return result.quote;
}

export function buildGeneratorTrace(draft: WebPackageDraft | StoredWebBooking["draft"]): GeneratorTrace {
  const flightSnapshot = (leg: DirectJourneyOption["outbound"], candidateId: string) => ({
    candidateId,
    airline: leg.airline,
    flightNumbers: leg.flight_number,
    origin: leg.origin,
    destination: leg.destination,
    departureAt: leg.departure_at,
    arrivalAt: leg.arrival_at,
    source: "iumrah Published",
    stops: leg.stops,
    durationMinutes: leg.duration_minutes,
    segments: [{
      airline: leg.airline,
      airlineCode: leg.airline_code,
      flightNumber: leg.flight_number,
      origin: leg.origin,
      destination: leg.destination,
      departureAt: leg.departure_at,
      arrivalAt: leg.arrival_at,
      originTerminal: null,
      destinationTerminal: null,
      aircraft: null,
      operatingCarrier: null,
      cabin: leg.cabin_class,
    }],
    connectionAirports: [],
  });
  const hotelSnapshot = (hotel: HotelSummary, roomId: string | null) => {
    const room = hotel.rooms.find((item) => item.id === roomId);
    return { hotelId: hotel.id, hotelName: hotel.name, city: hotel.city, roomId, roomName: room?.name ?? null, roomCategory: null };
  };
  return {
    quoteId: draft.quote.quoteId,
    outbound: flightSnapshot(draft.journey.outbound, draft.journey.outboundOfferId),
    inbound: flightSnapshot(draft.journey.inbound, draft.journey.inboundOfferId),
    makkahHotel: hotelSnapshot(draft.makkahHotel, draft.makkahRoomId),
    madinahHotel: hotelSnapshot(draft.madinahHotel, draft.madinahRoomId),
  };
}

export async function reconcileStoredBooking(booking: StoredWebBooking): Promise<{ booking: StoredWebBooking; commitOk: boolean; syncOk: boolean }> {
  let current = booking;
  let commitOk = !booking.pendingQuoteProof;
  if (booking.pendingQuoteProof) {
    try {
      const response = await fetch(`/api/package/quote/commit/${encodeURIComponent(booking.id)}`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-booking-token": booking.accessToken },
        body: JSON.stringify({ quoteProof: booking.pendingQuoteProof }),
      });
      commitOk = response.ok;
      if (response.ok) {
        const settled: StoredWebBooking = { ...booking };
        delete settled.pendingQuoteProof;
        current = settled;
        saveBooking(current);
      }
    } catch { commitOk = false; }
  }
  let syncOk = false;
  try {
    const profile = current.profile;
    const trace = current.generatorTrace ?? buildGeneratorTrace(current.draft);
    const response = await fetch(`/api/catalog/hotels/client/trips/${encodeURIComponent(current.id)}/sync`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-booking-token": current.accessToken },
      body: JSON.stringify({ ...(profile ?? {}), displayName: profile ? `${profile.firstName} ${profile.lastName}`.trim() : "", generatorTrace: trace }),
    });
    syncOk = response.ok;
  } catch { syncOk = false; }
  return { booking: current, commitOk, syncOk };
}

export function savePackageDraft(draft: WebPackageDraft) {
  window.sessionStorage.setItem(PACKAGE_DRAFT_KEY, JSON.stringify(draft));
}

export function loadPackageDraft(): WebPackageDraft | null {
  try {
    const value = window.sessionStorage.getItem(PACKAGE_DRAFT_KEY);
    if (!value) return null;
    const parsed = JSON.parse(value) as WebPackageDraft;
    return parsed?.version === 1 ? parsed : null;
  } catch { return null; }
}

export function saveBooking(booking: StoredWebBooking) {
  window.localStorage.setItem(BOOKING_KEY, JSON.stringify(booking));
}

export function loadBooking(): StoredWebBooking | null {
  try {
    const value = window.localStorage.getItem(BOOKING_KEY);
    return value ? JSON.parse(value) as StoredWebBooking : null;
  } catch { return null; }
}

export function clearPackageDraft() {
  window.sessionStorage.removeItem(PACKAGE_DRAFT_KEY);
}

export function formatMoney(value: number, currency = "USD") {
  return new Intl.NumberFormat("ru-RU", { style: "currency", currency, maximumFractionDigits: 0 }).format(value);
}

export function formatTripDate(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short" }).format(date);
}

export function formatLongTripDate(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("ru-RU", { weekday: "short", day: "numeric", month: "long" }).format(date);
}

export function formatTime(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(date);
}

export function formatDuration(minutes: number) {
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? `${hours} ч ${rest} мин` : `${hours} ч`;
}

export function selectableHotelStarsForTier(tier: PackageTier): number[] {
  return tier === "economy" ? [2, 1] : [hotelStarsForTier(tier)];
}

type HotelListItem = {
  id: string;
  name: string;
  city: string;
  stars: number | null;
  rating: number | null;
  reviewCount?: number | null;
  status?: string;
  coverImageURL?: string | null;
};

function normalizeHotelListItem(hotel: HotelListItem): HotelSummary {
  return {
    id: hotel.id,
    name: hotel.name,
    city: hotel.city,
    country: "Saudi Arabia",
    stars: hotel.stars,
    rating: hotel.rating,
    reviewCount: hotel.reviewCount ?? null,
    address: "",
    description: "",
    checkIn: null,
    checkOut: null,
    status: hotel.status ?? "active",
    amenities: [],
    images: hotel.coverImageURL ? [{ id: `cover:${hotel.id}`, url: hotel.coverImageURL, isCover: true, position: 0 }] : [],
    rooms: [],
  };
}

export async function fetchHotelsByCity(city: "Makkah" | "Madinah"): Promise<HotelSummary[]> {
  const aliases = city === "Makkah"
    ? ["Makkah"]
    : ["Madinah", "Medina", "Madina", "Medinah", "Al Madinah", "Al Medina", "Madinah Al Munawwarah", "Al Madinah Al Munawwarah"];
  const settled = await Promise.allSettled(aliases.map(async (alias) => {
    const response = await fetch(`/api/catalog/hotels?city=${encodeURIComponent(alias)}`, { cache: "no-store" });
    const body = await response.json() as { hotels?: HotelListItem[]; error?: string };
    if (!response.ok) throw new Error(body.error || "HOTELS_UNAVAILABLE");
    return (body.hotels ?? []).map(normalizeHotelListItem);
  }));
  const merged = new Map<string, HotelSummary>();
  for (const result of settled) {
    if (result.status !== "fulfilled") continue;
    for (const hotel of result.value) merged.set(hotel.id, hotel);
  }
  return [...merged.values()].sort((a, b) => {
    const starDelta = (b.stars ?? 0) - (a.stars ?? 0);
    return starDelta || a.name.localeCompare(b.name);
  });
}

export async function resolveHotelRoom(hotelId: string, travelers: TravelerSelection): Promise<string | null> {
  const categories = await fetchRoomCategories(hotelId);
  return preferredRoomId(categories, travelers);
}
