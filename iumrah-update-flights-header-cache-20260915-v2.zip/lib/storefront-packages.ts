import {
  fetchCuratedRecommendations,
  fetchStorefrontFlightBoard,
  recommendationRole,
  requestPackageQuote,
  resolveHotelForTier,
  type CuratedFlightRecommendation,
  type PackageTier,
  type PublishedFlightSelection,
  type StayPlan,
  type StorefrontFlightOption,
  type StorefrontLeg,
} from "@/lib/web-package";

export type StorefrontPackageKind = "makkah-only" | "makkah-madinah";
export type StorefrontPackageEntryMode = "flight-first" | "hotel-first";
export type StorefrontPackageStatus = "ready" | "calculating";

export type StorefrontPackage = {
  id: string;
  entryMode: StorefrontPackageEntryMode;
  status: StorefrontPackageStatus;
  originCode: string;
  originCity: string;
  destinationCode: string;
  tier: PackageTier;
  kind: StorefrontPackageKind;
  startDate: string;
  endDate: string;
  totalDays: number;
  totalNights: number;
  outbound: {
    airline: string;
    airlineCode: string;
    flightNumber: string;
    origin: string;
    destination: string;
    departureAt: string;
  };
  inbound: {
    airline: string;
    airlineCode: string;
    flightNumber: string;
    origin: string;
    destination: string;
    departureAt: string;
  };
  imageUrl: string;
  hotelName: string;
  hotelSecondaryName: string | null;
  makkahHotelId: string | null;
  madinahHotelId: string | null;
  routeSummary: string;
  pricePerPerson: number | null;
  totalPackagePrice: number | null;
  currency: string;
  isEstimated: boolean;
};

type Candidate = {
  key: string;
  selection: PublishedFlightSelection;
  originCode: string;
  destinationCode: string;
  tier: PackageTier;
  kind: StorefrontPackageKind;
  startDate: string;
  endDate: string;
  outbound: StorefrontLeg;
  inbound: StorefrontLeg;
};

export const STORE_ORIGINS = ["TAS", "SKD", "FEG", "NMA", "UGC", "BHK", "NCU", "TMJ", "KSQ", "AZN"] as const;

const ORIGIN_CITY_MAP: Record<string, string> = {
  TAS: "Tashkent",
  SKD: "Samarkand",
  FEG: "Fergana",
  NMA: "Namangan",
  UGC: "Urgench",
  BHK: "Bukhara",
  NCU: "Nukus",
  TMJ: "Termez",
  KSQ: "Karshi",
  AZN: "Andijan",
};

function dateOnly(value: string) {
  return value.slice(0, 10);
}

function utcDate(value: string) {
  return new Date(`${dateOnly(value)}T00:00:00Z`);
}

function addDays(value: string, days: number) {
  const date = utcDate(value);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function dayDistance(from: string, to: string) {
  const first = utcDate(from).getTime();
  const second = utcDate(to).getTime();
  return Math.round((second - first) / 86_400_000);
}

function coverImage(images: Array<{ url: string; isCover: boolean }>) {
  return images.find((item) => item.isCover)?.url || images[0]?.url || "/iumrah/hotels-showcase.jpeg";
}

function buildStay(kind: StorefrontPackageKind, startDate: string, endDate: string): StayPlan {
  const totalNights = Math.max(1, dayDistance(startDate, endDate));
  if (kind === "makkah-only") {
    return {
      startDate,
      endDate,
      totalNights,
      totalDays: totalNights + 1,
      makkahNights: totalNights,
      madinahNights: 0,
      makkahCheckIn: startDate,
      makkahCheckOut: endDate,
      madinahCheckIn: startDate,
      madinahCheckOut: startDate,
    };
  }

  const madinahNights = totalNights > 1 ? Math.max(1, Math.min(totalNights - 1, Math.floor(totalNights * 0.42))) : 0;
  const makkahNights = Math.max(1, totalNights - madinahNights);
  const madinahCheckIn = startDate;
  const madinahCheckOut = addDays(startDate, madinahNights);
  return {
    startDate,
    endDate,
    totalNights,
    totalDays: totalNights + 1,
    makkahNights,
    madinahNights,
    makkahCheckIn: madinahCheckOut,
    makkahCheckOut: endDate,
    madinahCheckIn,
    madinahCheckOut,
  };
}

function publicFlight(leg: StorefrontLeg) {
  return {
    airline: leg.airline,
    airlineCode: leg.airline_code,
    flightNumber: leg.flight_number,
    origin: leg.origin,
    destination: leg.destination,
    departureAt: leg.departure_at,
  };
}

function isSaudiAirport(code: string) {
  const value = code.trim().toUpperCase();
  return value === "JED" || value === "MED";
}

function packageKindForLegs(outbound: StorefrontLeg, inbound: StorefrontLeg) {
  const gap = dayDistance(outbound.departure_at, inbound.departure_at);
  if (!isSaudiAirport(outbound.destination) || !isSaudiAirport(inbound.origin)) return null;
  if (outbound.destination.toUpperCase() === "JED" && inbound.origin.toUpperCase() === "JED" && gap >= 2 && gap <= 3) {
    return { kind: "makkah-only" as const, tier: "comfort" as const, gap };
  }
  if (gap >= 4 && gap <= 15) {
    return { kind: "makkah-madinah" as const, tier: "standard" as const, gap };
  }
  return null;
}

function allowedReturnDestination(returnDestination: string, outboundOrigin: string) {
  const destination = returnDestination.trim().toUpperCase();
  const preferred = outboundOrigin.trim().toUpperCase();
  return destination === preferred || (preferred !== "TAS" && destination === "TAS");
}

function oneWayReturnCandidates(
  outbound: StorefrontLeg,
  options: StorefrontFlightOption[],
  returnDestination: string,
) {
  return options.filter((candidate) => {
    if (candidate.inbound) return false;
    if (candidate.currency.toUpperCase() !== "USD") return false;
    if (!Number.isFinite(candidate.perTravelerFare) || candidate.perTravelerFare <= 0) return false;
    if (!isSaudiAirport(candidate.outbound.origin)) return false;
    if (candidate.outbound.destination.toUpperCase() !== returnDestination.toUpperCase()) return false;
    return packageKindForLegs(outbound, candidate.outbound) !== null;
  });
}

function bestReturnOneWay(
  outbound: StorefrontLeg,
  options: StorefrontFlightOption[],
  returnDestination: string,
) {
  const candidates = oneWayReturnCandidates(outbound, options, returnDestination);
  if (!candidates.length) return null;

  if (outbound.destination.toUpperCase() === "JED") {
    const short = candidates.filter((candidate) => {
      const type = packageKindForLegs(outbound, candidate.outbound);
      return type?.kind === "makkah-only";
    });
    if (short.length) {
      return [...short].sort((a, b) => {
        const aGap = packageKindForLegs(outbound, a.outbound)?.gap ?? 99;
        const bGap = packageKindForLegs(outbound, b.outbound)?.gap ?? 99;
        const gapCompare = Math.abs(aGap - 3) - Math.abs(bGap - 3);
        if (gapCompare !== 0) return gapCompare;
        if (a.perTravelerFare !== b.perTravelerFare) return a.perTravelerFare - b.perTravelerFare;
        if (a.priority !== b.priority) return a.priority - b.priority;
        return a.outbound.departure_at.localeCompare(b.outbound.departure_at);
      })[0];
    }
  }

  const complementary = outbound.destination.toUpperCase() === "JED" ? "MED" : "JED";
  const long = candidates.filter((candidate) => packageKindForLegs(outbound, candidate.outbound)?.kind === "makkah-madinah");
  return [...long].sort((a, b) => {
    const aOpenJaw = a.outbound.origin.toUpperCase() === complementary ? 0 : 1;
    const bOpenJaw = b.outbound.origin.toUpperCase() === complementary ? 0 : 1;
    if (aOpenJaw !== bOpenJaw) return aOpenJaw - bOpenJaw;
    const aGap = packageKindForLegs(outbound, a.outbound)?.gap ?? 99;
    const bGap = packageKindForLegs(outbound, b.outbound)?.gap ?? 99;
    const gapCompare = Math.abs(aGap - 7) - Math.abs(bGap - 7);
    if (gapCompare !== 0) return gapCompare;
    if (a.perTravelerFare !== b.perTravelerFare) return a.perTravelerFare - b.perTravelerFare;
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.outbound.departure_at.localeCompare(b.outbound.departure_at);
  })[0] ?? null;
}

function candidateFromPair(
  outboundOption: StorefrontFlightOption,
  inboundOption: StorefrontFlightOption,
): Candidate | null {
  const type = packageKindForLegs(outboundOption.outbound, inboundOption.outbound);
  if (!type) return null;
  return {
    key: `storefront-pair:${outboundOption.id}:${inboundOption.id}`,
    selection: { completeID: null, outboundID: outboundOption.id, returnID: inboundOption.id },
    originCode: outboundOption.outbound.origin.toUpperCase(),
    destinationCode: outboundOption.outbound.destination.toUpperCase(),
    tier: type.tier,
    kind: type.kind,
    startDate: dateOnly(outboundOption.outbound.departure_at),
    endDate: dateOnly(inboundOption.outbound.departure_at),
    outbound: outboundOption.outbound,
    inbound: inboundOption.outbound,
  };
}

function buildCandidatesFromStorefrontBoard(options: StorefrontFlightOption[], origins: string[]) {
  const allowedOrigins = new Set(origins.map((value) => value.toUpperCase()));
  const candidates: Candidate[] = [];

  const anchors = options
    .filter((option) => {
      const origin = option.outbound.origin.toUpperCase();
      return allowedOrigins.has(origin) && !isSaudiAirport(origin) && isSaudiAirport(option.outbound.destination);
    })
    .sort((a, b) => {
      if (a.outbound.departure_at !== b.outbound.departure_at) return a.outbound.departure_at.localeCompare(b.outbound.departure_at);
      if (a.priority !== b.priority) return a.priority - b.priority;
      return a.perTravelerFare - b.perTravelerFare;
    });

  for (const option of anchors) {
    if (option.currency.toUpperCase() !== "USD") continue;
    if (!Number.isFinite(option.perTravelerFare) || option.perTravelerFare <= 0) continue;

    if (option.inbound) {
      const type = packageKindForLegs(option.outbound, option.inbound);
      if (!type || !allowedReturnDestination(option.inbound.destination, option.outbound.origin)) continue;
      candidates.push({
        key: `storefront-complete:${option.id}`,
        selection: { completeID: option.id, outboundID: null, returnID: null },
        originCode: option.outbound.origin.toUpperCase(),
        destinationCode: option.outbound.destination.toUpperCase(),
        tier: type.tier,
        kind: type.kind,
        startDate: dateOnly(option.outbound.departure_at),
        endDate: dateOnly(option.inbound.departure_at),
        outbound: option.outbound,
        inbound: option.inbound,
      });
      continue;
    }

    const preferredDestination = option.outbound.origin.toUpperCase();
    let returnOption = bestReturnOneWay(option.outbound, options, preferredDestination);
    if (!returnOption && preferredDestination !== "TAS") {
      returnOption = bestReturnOneWay(option.outbound, options, "TAS");
    }
    if (!returnOption) continue;
    const candidate = candidateFromPair(option, returnOption);
    if (candidate) candidates.push(candidate);
  }

  const deduped = new Map<string, Candidate>();
  for (const item of candidates) {
    const selectionKey = item.selection.completeID ?? `${item.selection.outboundID}:${item.selection.returnID}`;
    if (!deduped.has(selectionKey)) deduped.set(selectionKey, item);
  }
  return Array.from(deduped.values()).sort((a, b) => a.startDate.localeCompare(b.startDate));
}

function buildCandidatesForOrigin(originCode: string, recommendations: CuratedFlightRecommendation[]): Candidate[] {
  const complete = recommendations.filter(
    (item) => item.inbound && item.outbound.origin === originCode && allowedReturnDestination(item.inbound.destination, originCode),
  );
  const outbound = recommendations.filter(
    (item) => !item.inbound && recommendationRole(item) === "outbound" && item.outbound.origin === originCode,
  );
  const returns = recommendations.filter(
    (item) => !item.inbound && recommendationRole(item) === "return" && allowedReturnDestination(item.outbound.destination, originCode),
  );

  const candidates: Candidate[] = [];

  for (const item of [...complete].sort((a, b) => a.outboundDate.localeCompare(b.outboundDate))) {
    if (!item.inboundDate || !item.inbound) continue;
    const type = packageKindForLegs(item.outbound, item.inbound);
    if (!type) continue;
    candidates.push({
      key: `complete:${item.id}`,
      selection: { completeID: item.id, outboundID: null, returnID: null },
      originCode,
      destinationCode: item.outbound.destination,
      tier: type.tier,
      kind: type.kind,
      startDate: item.outboundDate,
      endDate: item.inboundDate,
      outbound: item.outbound,
      inbound: item.inbound,
    });
  }

  for (const outward of [...outbound].sort((a, b) => a.outboundDate.localeCompare(b.outboundDate))) {
    const exact = returns.filter((item) => item.outbound.destination.toUpperCase() === originCode.toUpperCase());
    const fallback = originCode.toUpperCase() === "TAS"
      ? []
      : returns.filter((item) => item.outbound.destination.toUpperCase() === "TAS");
    const possible = exact.length ? exact : fallback;
    const matching = possible
      .map((item) => ({ item, type: packageKindForLegs(outward.outbound, item.outbound) }))
      .filter((value): value is { item: CuratedFlightRecommendation; type: NonNullable<ReturnType<typeof packageKindForLegs>> } => value.type !== null)
      .sort((a, b) => {
        if (a.type.kind !== b.type.kind) return a.type.kind === "makkah-only" ? -1 : 1;
        const aTarget = a.type.kind === "makkah-only" ? Math.abs(a.type.gap - 3) : Math.abs(a.type.gap - 7);
        const bTarget = b.type.kind === "makkah-only" ? Math.abs(b.type.gap - 3) : Math.abs(b.type.gap - 7);
        return aTarget - bTarget || a.item.outboundDate.localeCompare(b.item.outboundDate);
      });
    const match = matching[0];
    if (!match) continue;
    candidates.push({
      key: `pair:${outward.id}:${match.item.id}`,
      selection: { completeID: null, outboundID: outward.id, returnID: match.item.id },
      originCode,
      destinationCode: outward.outbound.destination,
      tier: match.type.tier,
      kind: match.type.kind,
      startDate: outward.outboundDate,
      endDate: match.item.outboundDate,
      outbound: outward.outbound,
      inbound: match.item.outbound,
    });
  }

  const deduped = new Map<string, Candidate>();
  for (const item of candidates.sort((a, b) => a.startDate.localeCompare(b.startDate))) {
    const key = item.selection.completeID ?? `${item.selection.outboundID}:${item.selection.returnID}`;
    if (!deduped.has(key)) deduped.set(key, item);
  }
  return Array.from(deduped.values());
}

type ResolvedStorefrontHotel = Awaited<ReturnType<typeof resolveHotelForTier>>;

function pendingPackage(
  candidate: Candidate,
  hotels?: { makkah?: ResolvedStorefrontHotel | null; madinah?: ResolvedStorefrontHotel | null },
): StorefrontPackage {
  const stay = buildStay(candidate.kind, candidate.startDate, candidate.endDate);
  const makkah = hotels?.makkah ?? null;
  const madinah = hotels?.madinah ?? null;
  return {
    id: `pending:${candidate.key}`,
    entryMode: "flight-first",
    status: "calculating",
    originCode: candidate.originCode,
    originCity: ORIGIN_CITY_MAP[candidate.originCode] ?? candidate.originCode,
    destinationCode: candidate.destinationCode,
    tier: candidate.tier,
    kind: candidate.kind,
    startDate: stay.startDate,
    endDate: stay.endDate,
    totalDays: stay.totalDays,
    totalNights: stay.totalNights,
    outbound: publicFlight(candidate.outbound),
    inbound: publicFlight(candidate.inbound),
    imageUrl: makkah ? coverImage(makkah.hotel.images) : "/iumrah/hotels-showcase.jpeg",
    hotelName: makkah?.hotel.name ?? "",
    hotelSecondaryName: candidate.kind === "makkah-only" ? null : (madinah?.hotel.name ?? null),
    makkahHotelId: makkah?.hotel.id ?? null,
    madinahHotelId: candidate.kind === "makkah-only" ? null : (madinah?.hotel.id ?? null),
    routeSummary: candidate.kind === "makkah-only"
      ? `${candidate.outbound.origin} → ${candidate.outbound.destination} + ${candidate.inbound.origin} → ${candidate.inbound.destination} · ${stay.totalDays} d · Makkah only`
      : `${candidate.outbound.origin} → ${candidate.outbound.destination} + ${candidate.inbound.origin} → ${candidate.inbound.destination} · ${stay.totalDays} d · Makkah + Madinah`,
    pricePerPerson: null,
    totalPackagePrice: null,
    currency: "USD",
    isEstimated: true,
  };
}

async function candidatesForOrigins(origins: string[], baseUrl?: string) {
  try {
    const board = await fetchStorefrontFlightBoard(origins[0] ?? "TAS", baseUrl);
    const boardCandidates = buildCandidatesFromStorefrontBoard(board.options, origins);
    if (boardCandidates.length) return boardCandidates;
  } catch {
    // Older PackageEngine deployments can still serve the recommendations projection.
  }

  const settled = await Promise.allSettled(
    origins.map(async (originCode) => {
      const recommendations = await fetchCuratedRecommendations(originCode, baseUrl);
      return buildCandidatesForOrigin(originCode, recommendations);
    }),
  );

  return settled
    .flatMap((result) => (result.status === "fulfilled" ? result.value : []))
    .sort((a, b) => a.startDate.localeCompare(b.startDate));
}

export async function loadStorefrontCandidatePackages(options?: {
  maxPackages?: number;
  origins?: string[];
  baseUrl?: string;
}) {
  const origins = options?.origins?.length ? options.origins : Array.from(STORE_ORIGINS);
  const maxPackages = options?.maxPackages ?? 60;
  const candidates = await candidatesForOrigins(origins, options?.baseUrl);
  return candidates.slice(0, maxPackages).map((candidate) => pendingPackage(candidate));
}

async function mapWithConcurrency<T, R>(items: T[], concurrency: number, task: (item: T) => Promise<R | null>) {
  const output: Array<R | null> = new Array(items.length).fill(null);
  let cursor = 0;

  async function worker() {
    while (true) {
      const index = cursor;
      cursor += 1;
      if (index >= items.length) return;
      output[index] = await task(items[index]);
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
  return output.filter((item): item is R => item !== null);
}

export async function buildPricedStorefrontPackages(options?: {
  maxPackages?: number;
  origins?: string[];
  baseUrl?: string;
}) {
  const origins = options?.origins?.length ? options.origins : Array.from(STORE_ORIGINS);
  const maxPackages = options?.maxPackages ?? 60;
  const baseUrl = options?.baseUrl;
  const candidates = (await candidatesForOrigins(origins, baseUrl)).slice(0, maxPackages);
  if (!candidates.length) return [];

  const travelers = { adults: 2, children: 0, infants: 0, rooms: 1 };
  const hotelKeys = new Set<string>();
  for (const candidate of candidates) {
    hotelKeys.add(`${candidate.tier}:Makkah`);
    if (candidate.kind === "makkah-madinah") hotelKeys.add(`${candidate.tier}:Madinah`);
  }

  const hotelResults = await Promise.allSettled(
    Array.from(hotelKeys).map(async (key) => {
      const [tier, city] = key.split(":") as [PackageTier, "Makkah" | "Madinah"];
      return [key, await resolveHotelForTier(tier, city, travelers, baseUrl)] as const;
    }),
  );
  const hotelCache = new Map(
    hotelResults.flatMap((result) => (result.status === "fulfilled" ? [result.value] : [])),
  );

  return mapWithConcurrency(candidates, 4, async (candidate): Promise<StorefrontPackage | null> => {
    try {
      const makkah = hotelCache.get(`${candidate.tier}:Makkah`);
      const madinah = candidate.kind === "makkah-madinah" ? hotelCache.get(`${candidate.tier}:Madinah`) : null;
      if (!makkah || (candidate.kind === "makkah-madinah" && !madinah)) {
        return pendingPackage(candidate, { makkah, madinah });
      }

      const completeID = candidate.selection.completeID;
      const outboundID = candidate.selection.outboundID;
      const returnID = candidate.selection.returnID;
      const providerItineraryId = completeID
        ? `curated:${completeID}`
        : outboundID && returnID
          ? `curated:${outboundID}+${returnID}`
          : null;
      if (!providerItineraryId) return null;

      const stay = buildStay(candidate.kind, candidate.startDate, candidate.endDate);
      const journey = {
        id: providerItineraryId,
        providerItineraryId,
        outboundOfferId: completeID ?? outboundID ?? providerItineraryId,
        inboundOfferId: completeID ?? returnID ?? providerItineraryId,
        outbound: candidate.outbound,
        inbound: candidate.inbound,
        currency: "USD",
        observedAt: new Date().toISOString(),
      };

      const quote = await requestPackageQuote(
        {
          tier: candidate.tier,
          travelers,
          journey,
          stay,
          meals: { makkahLunch: false, makkahDinner: false, madinahDinner: false },
          transferVehicle: null,
          haramainEnabled: false,
          haramainFareClass: "economy",
          haramainTicketCount: 2,
          makkahHotelId: makkah.hotel.id,
          makkahRoomId: makkah.roomId,
          madinahHotelId: madinah?.hotel.id ?? null,
          madinahRoomId: madinah?.roomId ?? null,
        },
        baseUrl,
      );

      return {
        id: `${candidate.key}:${quote.quoteId}`,
        entryMode: "flight-first",
        status: "ready",
        originCode: candidate.originCode,
        originCity: ORIGIN_CITY_MAP[candidate.originCode] ?? candidate.originCode,
        destinationCode: candidate.destinationCode,
        tier: candidate.tier,
        kind: candidate.kind,
        startDate: stay.startDate,
        endDate: stay.endDate,
        totalDays: stay.totalDays,
        totalNights: stay.totalNights,
        outbound: publicFlight(candidate.outbound),
        inbound: publicFlight(candidate.inbound),
        imageUrl: coverImage(makkah.hotel.images),
        hotelName: makkah.hotel.name,
        hotelSecondaryName: candidate.kind === "makkah-only" ? null : (madinah?.hotel.name ?? null),
        makkahHotelId: makkah.hotel.id,
        madinahHotelId: candidate.kind === "makkah-only" ? null : (madinah?.hotel.id ?? null),
        routeSummary: candidate.kind === "makkah-only"
          ? `${candidate.outbound.origin} → ${candidate.outbound.destination} + ${candidate.inbound.origin} → ${candidate.inbound.destination} · ${stay.totalDays} d · Makkah only`
          : `${candidate.outbound.origin} → ${candidate.outbound.destination} + ${candidate.inbound.origin} → ${candidate.inbound.destination} · ${stay.totalDays} d · Makkah + Madinah`,
        pricePerPerson: quote.pricePerPerson,
        totalPackagePrice: quote.totalPackagePrice,
        currency: quote.currency,
        isEstimated: quote.isEstimated,
      };
    } catch {
      const makkah = hotelCache.get(`${candidate.tier}:Makkah`) ?? null;
      const madinah = candidate.kind === "makkah-madinah" ? (hotelCache.get(`${candidate.tier}:Madinah`) ?? null) : null;
      return pendingPackage(candidate, { makkah, madinah });
    }
  });
}

export function hotelFirstPackagesFromFlightFirst(items: StorefrontPackage[]) {
  const seen = new Set<string>();
  const hotelFirst: StorefrontPackage[] = [];

  for (const item of items) {
    if (!item.makkahHotelId) continue;
    const key = `${item.makkahHotelId}:${item.startDate}:${item.originCode}`;
    if (seen.has(key)) continue;
    seen.add(key);
    hotelFirst.push({
      ...item,
      id: `hotel-first:${item.makkahHotelId}:${item.id}`,
      entryMode: "hotel-first",
    });
  }

  return hotelFirst;
}

type StorefrontApiResponse = {
  ok?: boolean;
  items?: StorefrontPackage[];
};

export async function loadStorefrontPackages(options?: {
  maxPackages?: number;
  origins?: string[];
  mode?: StorefrontPackageEntryMode;
}) {
  const maxPackages = options?.maxPackages ?? 60;
  const mode = options?.mode ?? "flight-first";
  const params = new URLSearchParams({ mode, limit: String(maxPackages) });
  if (options?.origins?.length) params.set("origins", options.origins.join(","));

  try {
    const response = await fetch(`/api/storefront/packages?${params.toString()}`, { cache: "no-store" });
    const body = await response.json() as StorefrontApiResponse;
    if (response.ok && body.ok && Array.isArray(body.items) && body.items.length) {
      return body.items.slice(0, maxPackages);
    }
  } catch {
    // Direct-flight candidates below keep the storefront useful while cache/API recovers.
  }

  return loadStorefrontCandidatePackages({ maxPackages, origins: options?.origins });
}
