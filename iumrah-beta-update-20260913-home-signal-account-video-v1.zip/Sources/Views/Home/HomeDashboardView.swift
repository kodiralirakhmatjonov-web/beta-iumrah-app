import SwiftUI

struct HomeDashboardView: View {
    @EnvironmentObject private var chrome: AppChromeStore
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var bookings: BookingStore
    @EnvironmentObject private var account: IumrahAccountStore
    @ObservedObject private var clientNotifications = ClientNotificationCenter.shared
    @State private var showZiyarats = false
    @State private var expandedHomeFAQID: String?

    private var activeSession: StoredBookingSession? {
        bookings.sessions.first { $0.effectiveStatus.uppercased() != "COMPLETED" }
    }

    var body: some View {
        marketingHome
            .task(id: activeSession?.id) {
                await bookings.refreshAll()
                while !Task.isCancelled {
                    if let activeSession { _ = try? await bookings.loadESIMs(for: activeSession.id) }
                    try? await Task.sleep(nanoseconds: 120_000_000_000)
                }
            }
            .fullScreenCover(isPresented: $showZiyarats) {
                ZiyaratJourneyView()
                    .environmentObject(settings)
                    .environmentObject(chrome)
            }
    }

    private var marketingHome: some View {
        ScrollView {
            VStack(spacing: 22) {
                IumrahRootPageTitle(title: L10n.text("tab_home", settings.language), usesBrandLogo: true, brandScale: 1.25, showsConnectivityStatus: true)
                if !clientNotifications.homeNotifications.isEmpty {
                    SystemNotificationsCarouselView(
                        notifications: Array(clientNotifications.homeNotifications.prefix(5)),
                        onOpen: { openSystemNotification($0) },
                        onDismiss: { dismissSystemNotification($0) }
                    )
                }
                HomeEmotionalJourneyPrompt()
                HomeVideoCarousel()
                IumrahBackendSystemHomeCard()
                hero
                friendsHomeCard
                UmrahAdvisorHomeCard()
                ziyaratsHomeCard
                confidenceStrip
                philosophyCard
                connectedTripCard
                esimHomeCard
                careCard
                hotelCard
                flightsHomeCard
                personalUmrahFAQ
            }
            .padding(.horizontal, IumrahDesign.pagePadding)
            .padding(.top, 10)
            .padding(.bottom, 0)
        }
        .background(Color.iumrahPageBackground)
    }


    private func dismissSystemNotification(_ notification: ClientSystemNotification) {
        IumrahHaptics.selection()
        clientNotifications.dismissFromHome(notification)
    }

    private func openSystemNotification(_ notification: ClientSystemNotification) {
        IumrahHaptics.selection()
        Task { await clientNotifications.markOpened(notification, accountToken: account.bearerToken) }
        switch notification.destination {
        case "hotels": chrome.navigate(to: .hotels)
        case "bookings": chrome.navigate(to: .booking)
        case "care": chrome.navigate(to: .care)
        case "account": chrome.navigate(to: .account)
        case "booking":
            if let bookingID = notification.destinationBookingID, bookings.booking(id: bookingID) != nil {
                chrome.openBooking(id: bookingID)
            } else {
                chrome.navigate(to: .booking)
            }
        default: chrome.navigate(to: .home)
        }
    }

    private func activeJourneyHome(_ session: StoredBookingSession) -> some View {
        ZStack {
            Image("MakkahBackground")
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()
                .ignoresSafeArea()

            LinearGradient(
                colors: [Color.black.opacity(0.48), Color.black.opacity(0.12), Color.black.opacity(0.18)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 18) {
                    IumrahRootPageTitle(
                        title: L10n.text("tab_home", settings.language),
                        showsMakkahTime: true,
                        lightStyle: true,
                        usesBrandLogo: true,
                        showsConnectivityStatus: true
                    )

                    activeBookingCard(session)
                    activeCareCard(session)

                    Color.clear
                        .frame(height: 330)
                        .accessibilityHidden(true)
                }
                .padding(.horizontal, IumrahDesign.pagePadding)
                .padding(.top, 10)
                .padding(.bottom, 30)
            }
        }
    }

    private func activeBookingCard(_ session: StoredBookingSession) -> some View {
        VStack(alignment: .leading, spacing: 17) {
            HStack(alignment: .center) {
                Label(L10n.text("home_hero_kicker", settings.language), systemImage: "moon.stars.fill")
                    .font(.caption.weight(.bold))
                    .tracking(0.7)
                    .foregroundStyle(Color.black.opacity(0.58))

                Spacer()

                IumrahIconBadge(
                    systemName: statusIcon(session.effectiveStatus),
                    role: IumrahBookingStatusVisual.role(for: session.effectiveStatus),
                    size: 36,
                    symbolSize: 15,
                    shape: .circle
                )
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(L10n.status(session.effectiveStatus, settings.language))
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .tracking(-0.6)
                    .foregroundStyle(Color.black)

                if let travelerName = session.travelerName, !travelerName.isEmpty {
                    Text(travelerName)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color.black.opacity(0.58))
                }
            }

            Rectangle()
                .fill(Color.black.opacity(0.08))
                .frame(height: 1)

            VStack(spacing: 12) {
                journeySummaryRow(
                    icon: "airplane",
                    title: L10n.text("route_label", settings.language),
                    value: "\(session.booking.route.originCode) → \(session.booking.route.outboundDestination)"
                )
                journeySummaryRow(
                    icon: "calendar",
                    title: L10n.text("detail_dates", settings.language),
                    value: "\(L10n.date(session.booking.input.startDate, settings.language)) – \(L10n.date(session.booking.input.endDate, settings.language))"
                )
                if !session.booking.hotelNames.makkah.isEmpty {
                    journeySummaryRow(
                        icon: "building.2.fill",
                        title: L10n.text("detail_hotel", settings.language),
                        value: session.booking.hotelNames.makkah
                    )
                }
            }

            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(L10n.text("final_price", settings.language))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Color.black.opacity(0.50))
                    Text(money(session.booking.perPilgrimUsd))
                        .font(.system(size: 27, weight: .bold, design: .rounded))
                        .foregroundStyle(Color.black)
                }
                Spacer()
                if let pilgrimID = session.displayPilgrimID {
                    Text("ID \(pilgrimID)")
                        .font(.caption2.monospaced().weight(.semibold))
                        .foregroundStyle(Color.black.opacity(0.42))
                }
            }

            NavigationLink {
                BookingDetailView(bookingID: session.id)
            } label: {
                HStack {
                    Text(L10n.text("open_booking", settings.language))
                    Spacer()
                    Image(systemName: "arrow.up.right")
                }
                .font(.headline)
                .foregroundStyle(.white)
                .padding(.horizontal, 18)
                .frame(height: 54)
                .background(Color.black)
                .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(20)
        .background(Color.white.opacity(0.96))
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.white.opacity(0.38), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.18), radius: 28, y: 14)
    }

    private func journeySummaryRow(icon: String, title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            IumrahIconBadge(systemName: icon, size: 34, symbolSize: 14, shape: .circle)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(Color.black.opacity(0.48))
                Text(value)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.black)
                    .lineLimit(2)
            }
            Spacer(minLength: 0)
        }
    }

    private func activeCareCard(_ session: StoredBookingSession) -> some View {
        Button {
            chrome.navigate(to: .care)
        } label: {
            HStack(spacing: 14) {
                Image("CareMark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .padding(5)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))

                VStack(alignment: .leading, spacing: 4) {
                    Text("iumrah Care")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text(L10n.text("care_subtitle", settings.language))
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.76))
                        .lineLimit(2)
                }

                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.72))
            }
            .padding(16)
            .background {
                LinearGradient(
                    colors: [Color.iumrahCareDark.opacity(0.96), Color.iumrahCareLight.opacity(0.88)],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            }
            .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.16), lineWidth: 1)
            }
            .shadow(color: Color.iumrahCareDark.opacity(0.22), radius: 24, y: 12)
        }
        .buttonStyle(.plain)
        .accessibilityHint(session.displayPilgrimID.map { "ID \($0)" } ?? "")
    }

    private var ziyaratsHomeCard: some View {
        Button {
            IumrahHaptics.selection()
            showZiyarats = true
        } label: {
            ZStack(alignment: .bottomLeading) {
                Image("ZiyaratQuba3")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 255)
                    .clipped()

                LinearGradient(
                    colors: [.clear, Color.black.opacity(0.16), Color.black.opacity(0.82)],
                    startPoint: .top,
                    endPoint: .bottom
                )

                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 7) {
                        Image(systemName: "map.fill")
                        Text("MAKKAH · MADINAH")
                    }
                    .font(.caption.weight(.bold))
                    .tracking(0.5)
                    .foregroundStyle(.white.opacity(0.86))

                    Text(ziyaratsHomeTitle)
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .tracking(-0.6)
                        .foregroundStyle(.white)

                    Text(ziyaratsHomeSubtitle)
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.80))
                        .lineLimit(4)
                        .fixedSize(horizontal: false, vertical: true)

                    HStack(spacing: 6) {
                        Text(ziyaratsHomeCTA)
                        Image(systemName: "arrow.right")
                    }
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.top, 2)
                }
                .padding(20)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 255)
            .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.14), lineWidth: 0.7)
            }
            .shadow(color: .black.opacity(0.16), radius: 24, y: 11)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("iumrah Ziyarats")
    }

    private var ziyaratsHomeTitle: String {
        "iumrah Ziyarats"
    }

    private var ziyaratsHomeSubtitle: String {
        switch settings.language {
        case .russian: return "Священные и исторические места Мекки и Медины — в одном маршруте. Доступ к iumrah Ziyarats включён в iumrah Services вашего пакета."
        case .english: return "Sacred and historic places across Makkah and Madinah in one journey. Access to iumrah Ziyarats is included with your package’s iumrah Services."
        case .uzbek: return "Makka va Madinadagi muqaddas hamda tarixiy joylar — bitta yo‘nalishda. iumrah Ziyarats sizning paketingizdagi iumrah Services tarkibiga kiradi."
        case .uzbekCyrillic: return "Макка ва Мадинадаги муқаддас ҳамда тарихий жойлар — битта йўналишда. iumrah Ziyarats сизнинг пакетингиздаги iumrah Services таркибига киради."
        }
    }

    private var ziyaratsHomeCTA: String {
        switch settings.language {
        case .russian: return "Открыть Ziyarats"
        case .english: return "Open Ziyarats"
        case .uzbek: return "Ziyarats’ni ochish"
        case .uzbekCyrillic: return "Ziyarats’ни очиш"
        }
    }

    private var flightsHomeCard: some View {
        NavigationLink {
            IumrahFlightsView()
        } label: {
            Image("IumrahFlightsHomeCard")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .strokeBorder(Color.primary.opacity(0.07), lineWidth: 1)
                }
                .shadow(color: .black.opacity(0.18), radius: 24, y: 12)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("iumrah Flights")
    }

    private var flightsWorldFooter: some View {
        let pageBackground = Color.iumrahPageBackground

        return VStack(spacing: 0) {
            Text("From the world to Mecca")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .tracking(-0.7)
                .foregroundStyle(.primary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
                .padding(.top, 34)
                .padding(.bottom, 8)
                .allowsHitTesting(false)

            ZStack {
                IumrahInteractiveGlobe(presentation: .worldToMakkah)
                    .frame(height: 390)
                    // Fade the complete MapKit surface itself, including its black sky,
                    // so no rectangular map boundary survives against Home's background.
                    .mask {
                        LinearGradient(
                            stops: [
                                .init(color: .clear, location: 0.00),
                                .init(color: .white.opacity(0.16), location: 0.08),
                                .init(color: .white, location: 0.25),
                                .init(color: .white, location: 0.73),
                                .init(color: .white.opacity(0.20), location: 0.93),
                                .init(color: .clear, location: 1.00)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    }

                // A second two-sided blend uses the exact Home page background color.
                // This keeps the transition seamless in both light and dark appearance.
                LinearGradient(
                    stops: [
                        .init(color: pageBackground, location: 0.00),
                        .init(color: pageBackground.opacity(0.82), location: 0.07),
                        .init(color: .clear, location: 0.24),
                        .init(color: .clear, location: 0.74),
                        .init(color: pageBackground.opacity(0.78), location: 0.93),
                        .init(color: pageBackground, location: 1.00)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .allowsHitTesting(false)
            }
            .frame(height: 350)
            .clipped()
            .padding(.bottom, 84)
        }
        .frame(maxWidth: .infinity)
        .background(pageBackground)
        .padding(.horizontal, -IumrahDesign.pagePadding)
    }

    private var hero: some View {
        Button {
            IumrahHaptics.soft()
            chrome.startNewTrip()
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                ZStack {
                    Color.white

                    Image("IumrahConfiguratorHero")
                        .resizable()
                        .scaledToFit()
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 210)
                .clipped()

                VStack(alignment: .leading, spacing: 15) {
                    HStack(spacing: 8) {
                        Label("iumrah Configurator", systemImage: "slider.horizontal.3")
                            .font(.caption.weight(.bold))
                            .tracking(0.45)
                            .foregroundStyle(Color.black.opacity(0.58))
                        Spacer(minLength: 8)
                        Text(configuratorTimeBadge)
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(Color.black.opacity(0.62))
                            .padding(.horizontal, 10)
                            .frame(height: 29)
                            .background(Color.white.opacity(0.72), in: Capsule())
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text(configuratorHeroTitle)
                            .font(.system(size: 31, weight: .bold, design: .rounded))
                            .tracking(-0.75)
                            .foregroundStyle(.black)
                            .fixedSize(horizontal: false, vertical: true)

                        Text(configuratorHeroBody)
                            .font(.system(size: 15, weight: .regular, design: .rounded))
                            .foregroundStyle(Color.black.opacity(0.64))
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    HStack(spacing: 8) {
                        configuratorChip("airplane")
                        configuratorChip("building.2.fill")
                        configuratorChip("car.fill")
                        configuratorChip("heart.fill")
                        Spacer(minLength: 0)
                    }

                    HStack(spacing: 10) {
                        Text(configuratorHeroCTA)
                        Spacer(minLength: 8)
                        Image(systemName: "arrow.right")
                    }
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .frame(height: 54)
                    .background(Color.black, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .padding(20)
                .background(
                    LinearGradient(
                        colors: [
                            Color(red: 0.92, green: 0.95, blue: 1.00),
                            Color(red: 0.96, green: 0.93, blue: 1.00),
                            Color(red: 0.98, green: 0.96, blue: 0.93)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            }
            .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .strokeBorder(Color.black.opacity(0.055), lineWidth: 0.8)
            }
            .shadow(color: Color.black.opacity(0.09), radius: 24, y: 12)
            .contentShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(configuratorHeroTitle)
    }

    private func configuratorChip(_ systemName: String) -> some View {
        Image(systemName: systemName)
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(Color.black.opacity(0.72))
            .frame(width: 35, height: 35)
            .background(Color.white.opacity(0.70), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
    }

    private var configuratorTimeBadge: String {
        switch settings.language {
        case .russian: return "≈ 5 минут"
        case .english: return "≈ 5 min"
        case .uzbek: return "≈ 5 daqiqa"
        case .uzbekCyrillic: return "≈ 5 дақиқа"
        }
    }

    private var configuratorHeroTitle: String {
        switch settings.language {
        case .russian: return "Соберите свою Умру за 5 минут"
        case .english: return "Build your Umrah in 5 minutes"
        case .uzbek: return "Umrangizni 5 daqiqada tuzing"
        case .uzbekCyrillic: return "Умрангизни 5 дақиқада тузинг"
        }
    }

    private var configuratorHeroBody: String {
        switch settings.language {
        case .russian: return "Персональный пакет для вас, вашей семьи или друзей — без обязательной туристической группы из 30–50 человек. Перелёт, отель, трансфер и iumrah Services собираются в одну поездку."
        case .english: return "A personal package for you, your family or friends — without having to join a 30–50 person tour group. Flights, hotel, transfer and iumrah Services come together as one journey."
        case .uzbek: return "Siz, oilangiz yoki do‘stlaringiz uchun shaxsiy paket — 30–50 kishilik majburiy tur guruhisiz. Parvoz, mehmonxona, transfer va iumrah Services bitta safarga birlashadi."
        case .uzbekCyrillic: return "Сиз, оилангиз ёки дўстларингиз учун шахсий пакет — 30–50 кишилик мажбурий тур гуруҳисиз. Парвоз, меҳмонхона, трансфер ва iumrah Services битта сафарга бирлашади."
        }
    }

    private var configuratorHeroCTA: String {
        switch settings.language {
        case .russian: return "Создать мою Умру"
        case .english: return "Create my Umrah"
        case .uzbek: return "Umramni yaratish"
        case .uzbekCyrillic: return "Умрамни яратиш"
        }
    }

    private var friendsHomeCard: some View {
        NavigationLink {
            IumrahGiftCardsView()
        } label: {
            HStack(spacing: 16) {
                IumrahIconBadge(systemName: "gift.fill", role: .gift, size: 82, symbolSize: 25, cornerRadius: 22)
                .overlay(alignment: .topTrailing) {
                    Text("3")
                        .font(.caption2.monospaced().weight(.bold))
                        .foregroundStyle(.black)
                        .frame(width: 26, height: 26)
                        .background(.white, in: Circle())
                        .offset(x: 5, y: -5)
                }

                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 7) {
                        Text("iumrah Gift Card")
                            .font(.headline)
                        Text("3 × $100")
                            .font(.caption2.monospaced().weight(.bold))
                            .foregroundStyle(.secondary)
                    }
                    Text(friendsHomeSubtitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(3)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .iumrahCard()
        }
        .buttonStyle(.plain)
    }

    private var friendsHomeSubtitle: String {
        switch settings.language {
        case .russian: return "Подарочные карты для близких · $100 на умру и $100 в iUmrah Balance после подтверждения и оплаты."
        case .english: return "Gift cards for someone close · $100 toward Umrah and $100 in iUmrah Balance after confirmation and payment."
        case .uzbek: return "Yaqinlar uchun Gift Card · Umrah uchun $100 va tasdiqlanib to‘langach $100 iUmrah Balance."
        case .uzbekCyrillic: return "Яқинлар учун Gift Card · Умра учун $100 ва тасдиқланиб тўлангач $100 iUmrah Balance."
        }
    }

    private var confidenceStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                chip(icon: "building.2.fill", text: L10n.text("tab_hotels", settings.language))
                chip(icon: "airplane", text: L10n.text("step_flight", settings.language))
                chip(icon: "heart.fill", text: "iumrah Care")
            }
        }
    }

    private func chip(icon: String, text: String) -> some View {
        Label(text, systemImage: icon)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 14)
            .frame(height: 40)
            .background(Color.iumrahCardBackground)
            .clipShape(Capsule())
            .overlay { Capsule().strokeBorder(Color.primary.opacity(0.05), lineWidth: 1) }
    }

    private var philosophyCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("iumrah")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .padding(.horizontal, 14)
                .frame(height: 36)
                .background(Color.iumrahRaisedBackground)
                .clipShape(Capsule())
            Text(L10n.text("home_philosophy_title", settings.language))
                .font(.system(size: 28, weight: .bold, design: .rounded))
            Text(L10n.text("home_philosophy_body", settings.language))
                .font(.body)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahMarketingCard()
    }

    private var connectedTripCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 9) {
                journeyIcon("airplane")
                connector
                journeyIcon("building.2.fill")
                connector
                journeyIcon("car.fill")
                connector
                journeyIcon("moon.stars.fill")
                connector
                journeyIcon("heart.fill")
            }

            Text(L10n.text("home_connected_title", settings.language))
                .font(.system(size: 27, weight: .bold, design: .rounded))
            Text(L10n.text("home_connected_body", settings.language))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahMarketingCard()
    }

    private var esimHomeCard: some View {
        Button { chrome.presentESIM() } label: {
            HStack(spacing: 16) {
                if let session = activeSession, let profile = bookings.primaryESIM(for: session.id) {
                    ZStack {
                        Circle().stroke(Color.primary.opacity(0.08), lineWidth: 8)
                        if profile.usageAvailable {
                            Circle()
                                .trim(from: 0, to: profile.remainingFraction)
                                .stroke(Color.iumrahCareDark, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                                .rotationEffect(.degrees(-90))
                            VStack(spacing: 0) {
                                Text(homeDataText(profile.remainingMB))
                                    .font(.system(size: 13, weight: .bold, design: .rounded))
                                Text(homeESIMCopy(.left))
                                    .font(.system(size: 9, weight: .semibold))
                                    .foregroundStyle(.secondary)
                            }
                        } else {
                            VStack(spacing: 4) {
                                ProgressView().controlSize(.small)
                                Text("AUTO")
                                    .font(.system(size: 9, weight: .bold))
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .frame(width: 82, height: 82)

                    VStack(alignment: .leading, spacing: 5) {
                        Text("iumrah eSIM")
                            .font(.headline)
                        Text(profile.hasActivationData ? homeESIMCopy(.ready) : homeESIMCopy(.assigned))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                        Text(profile.hasActivationData ? homeESIMCopy(.activate) : homeESIMCopy(.open))
                            .font(.caption.weight(.bold))
                            .foregroundStyle(IumrahIconRole.connectivity.color)
                    }
                } else {
                    IumrahIconBadge(systemName: "simcard.fill", role: .message, size: 82, symbolSize: 27, cornerRadius: 22)

                    VStack(alignment: .leading, spacing: 5) {
                        Text("iumrah eSIM")
                            .font(.headline)
                        Text(homeESIMCopy(.packageOnly))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .lineLimit(3)
                        Text(homeESIMCopy(.details))
                            .font(.caption.weight(.bold))
                            .foregroundStyle(IumrahIconRole.connectivity.color)
                    }
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .iumrahCard()
        }
        .buttonStyle(.plain)
    }

    private enum HomeESIMCopyKey { case left, ready, assigned, activate, open, packageOnly, details }

    private func homeESIMCopy(_ key: HomeESIMCopyKey) -> String {
        switch (settings.language, key) {
        case (.russian, .left): return "осталось"
        case (.russian, .ready): return "Профиль готов. Активируйте eSIM на iPhone."
        case (.russian, .assigned): return "eSIM привязана к вашей поездке."
        case (.russian, .activate): return "Активировать eSIM"
        case (.russian, .open): return "Открыть eSIM"
        case (.russian, .packageOnly): return "В первой версии eSIM доступна только внутри Umrah-пакета."
        case (.russian, .details): return "Тарифы и активация"
        case (.english, .left): return "left"
        case (.english, .ready): return "Your profile is ready. Activate eSIM on iPhone."
        case (.english, .assigned): return "eSIM is assigned to your trip."
        case (.english, .activate): return "Activate eSIM"
        case (.english, .open): return "Open eSIM"
        case (.english, .packageOnly): return "In V1, eSIM is available only inside an Umrah package."
        case (.english, .details): return "Plans & activation"
        case (.uzbek, .left): return "qoldi"
        case (.uzbek, .ready): return "Profil tayyor. iPhone’da eSIM’ni faollashtiring."
        case (.uzbek, .assigned): return "eSIM safaringizga biriktirilgan."
        case (.uzbek, .activate): return "eSIM’ni faollashtirish"
        case (.uzbek, .open): return "eSIM’ni ochish"
        case (.uzbek, .packageOnly): return "V1’da eSIM faqat Umra paketi tarkibida mavjud."
        case (.uzbek, .details): return "Tariflar va faollashtirish"
        case (.uzbekCyrillic, .left): return "қолди"
        case (.uzbekCyrillic, .ready): return "Профил тайёр. iPhone’да eSIM’ни фаоллаштиринг."
        case (.uzbekCyrillic, .assigned): return "eSIM сафарингизга бириктирилган."
        case (.uzbekCyrillic, .activate): return "eSIM’ни фаоллаштириш"
        case (.uzbekCyrillic, .open): return "eSIM’ни очиш"
        case (.uzbekCyrillic, .packageOnly): return "V1’да eSIM фақат Умра пакети таркибида мавжуд."
        case (.uzbekCyrillic, .details): return "Тарифлар ва фаоллаштириш"
        }
    }

    private func homeDataText(_ mb: Double) -> String {
        if mb >= 1024 { return String(format: "%.1f GB", mb / 1024) }
        return "\(Int(max(0, mb).rounded())) MB"
    }

    private func journeyIcon(_ name: String) -> some View {
        IumrahIconBadge(systemName: name, size: 34, symbolSize: 13, shape: .circle)
    }

    private var connector: some View {
        Capsule()
            .fill(Color.primary.opacity(0.10))
            .frame(maxWidth: .infinity)
            .frame(height: 2)
    }

    private var careCard: some View {
        Button {
            chrome.navigate(to: .care)
        } label: {
            HStack(alignment: .center, spacing: 16) {
                Image("CareMark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 72, height: 72)
                    .padding(8)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                VStack(alignment: .leading, spacing: 7) {
                    Text("iumrah Care")
                        .font(.headline)
                    Text(L10n.text("care_subtitle", settings.language))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(3)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .iumrahCard()
        }
        .buttonStyle(.plain)
    }

    private var hotelCard: some View {
        Button {
            chrome.navigate(to: .hotels)
        } label: {
            HStack(alignment: .center, spacing: 16) {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(LinearGradient(colors: [Color.iumrahCareLight.opacity(0.35), Color.iumrahRaisedBackground], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 88, height: 88)
                    .overlay(IumrahIconBadge(systemName: "building.2", role: .hotel, size: 58, symbolSize: 25, cornerRadius: 18))
                VStack(alignment: .leading, spacing: 7) {
                    Text(L10n.text("hotels_title", settings.language))
                        .font(.headline)
                    Text(L10n.text("hotels_subtitle", settings.language))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(4)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .iumrahCard()
        }
        .buttonStyle(.plain)
    }

    private var personalUmrahFAQ: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 7) {
                Text("iumrah")
                    .font(.caption.weight(.bold))
                    .tracking(0.9)
                    .foregroundStyle(.secondary)

                Text(personalUmrahFAQTitle)
                    .font(.system(size: 29, weight: .bold, design: .rounded))
                    .tracking(-0.6)

                Text(personalUmrahFAQSubtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(spacing: 0) {
                ForEach(Array(homeFAQItems.enumerated()), id: \.element.id) { index, item in
                    Button {
                        IumrahHaptics.selection()
                        withAnimation(.spring(response: 0.34, dampingFraction: 0.88)) {
                            expandedHomeFAQID = expandedHomeFAQID == item.id ? nil : item.id
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 0) {
                            HStack(alignment: .center, spacing: 12) {
                                Text(item.question)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.primary)
                                    .multilineTextAlignment(.leading)
                                    .fixedSize(horizontal: false, vertical: true)

                                Spacer(minLength: 8)

                                Image(systemName: "chevron.down")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.secondary)
                                    .rotationEffect(.degrees(expandedHomeFAQID == item.id ? 180 : 0))
                            }
                            .padding(.vertical, 16)

                            if expandedHomeFAQID == item.id {
                                Text(item.answer)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .padding(.bottom, 17)
                                    .transition(.opacity.combined(with: .move(edge: .top)))
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)

                    if index < homeFAQItems.count - 1 {
                        Divider()
                    }
                }
            }
            .padding(.horizontal, 18)
            .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(Color.primary.opacity(0.055), lineWidth: 0.8)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 92)
    }

    private var personalUmrahFAQTitle: String {
        switch settings.language {
        case .russian: return "Персональная Умра — для вас и ваших близких"
        case .english: return "A personal Umrah — for you and the people you choose"
        case .uzbek: return "Shaxsiy Umra — siz va yaqinlaringiz uchun"
        case .uzbekCyrillic: return "Шахсий Умра — сиз ва яқинларингиз учун"
        }
    }

    private var personalUmrahFAQSubtitle: String {
        switch settings.language {
        case .russian: return "iumrah не привязывает вас к стандартной группе. Соберите поездку для себя, семьи или друзей и управляйте ею как одной персональной Umrah."
        case .english: return "iumrah does not tie you to a standard tour group. Build one personal Umrah for yourself, your family or friends and manage the journey in one place."
        case .uzbek: return "iumrah sizni standart tur guruhiga bog‘lamaydi. O‘zingiz, oilangiz yoki do‘stlaringiz uchun shaxsiy Umra tuzing va safarni bitta joydan boshqaring."
        case .uzbekCyrillic: return "iumrah сизни стандарт тур гуруҳига боғламайди. Ўзингиз, оилангиз ёки дўстларингиз учун шахсий Умра тузинг ва сафарни битта жойдан бошқаринг."
        }
    }

    private var homeFAQItems: [HomeFAQItem] {
        switch settings.language {
        case .russian:
            return [
                HomeFAQItem(id: "what", question: "Что такое iumrah?", answer: "iumrah — платформа для самостоятельной и персональной Умры. Она помогает собрать перелёт, отель, трансфер и сервисы в один понятный пакет и затем вести поездку в одном приложении."),
                HomeFAQItem(id: "why", question: "Почему был создан iumrah?", answer: "Чтобы паломнику не приходилось зависеть от большой туристической группы или разбираться в десятках разрозненных бронирований. Идея iumrah — дать больше контроля, прозрачности и заботы на каждом этапе поездки."),
                HomeFAQItem(id: "personal", question: "Что значит «персональная Умра»?", answer: "Поездка собирается вокруг вас: ваших дат, бюджета, уровня отеля и выбранных услуг. Это не обязательная группа из 30–50 незнакомых людей — вы сами выбираете, с кем совершать Умру."),
                HomeFAQItem(id: "family", question: "Можно поехать только с семьёй или друзьями?", answer: "Да. Пакет можно собрать для одного человека, пары, семьи или друзей. В поездке остаются только те люди, которых вы сами добавили."),
                HomeFAQItem(id: "care", question: "А если я не хочу собирать всё самостоятельно?", answer: "Обратитесь в iumrah Care. Мы поможем подобрать вариант, проверить детали и оформить поездку, сохранив персональный формат без обязательной большой группы.")
            ]
        case .english:
            return [
                HomeFAQItem(id: "what", question: "What is iumrah?", answer: "iumrah is a platform for independent, personal Umrah. It brings flights, hotel, transfer and services into one clear package and then keeps the journey in one app."),
                HomeFAQItem(id: "why", question: "Why was iumrah created?", answer: "So a pilgrim does not have to depend on a large tour group or manage many disconnected bookings. iumrah is built around more control, transparency and care throughout the journey."),
                HomeFAQItem(id: "personal", question: "What does ‘personal Umrah’ mean?", answer: "The journey is built around your dates, budget, hotel level and chosen services. There is no required group of 30–50 strangers — you decide who travels with you."),
                HomeFAQItem(id: "family", question: "Can I travel only with family or friends?", answer: "Yes. Build a package for one person, a couple, family or friends. Your journey contains only the people you choose to add."),
                HomeFAQItem(id: "care", question: "What if I do not want to build everything myself?", answer: "Contact iumrah Care. We can help select, verify and arrange the trip while keeping the personal format without a required large group.")
            ]
        case .uzbek:
            return [
                HomeFAQItem(id: "what", question: "iumrah nima?", answer: "iumrah — mustaqil va shaxsiy Umra uchun platforma. U parvoz, mehmonxona, transfer va xizmatlarni bitta tushunarli paketga birlashtiradi va safarni bitta ilovada boshqarishga yordam beradi."),
                HomeFAQItem(id: "why", question: "iumrah nima uchun yaratildi?", answer: "Ziyoratchi katta tur guruhiga bog‘lanib qolmasligi va ko‘plab alohida bronlarni boshqarmasligi uchun. iumrah safar davomida ko‘proq nazorat, shaffoflik va g‘amxo‘rlik berish uchun yaratilgan."),
                HomeFAQItem(id: "personal", question: "«Shaxsiy Umra» nimani anglatadi?", answer: "Safar sizning sanalaringiz, budjetingiz, mehmonxona darajasi va tanlagan xizmatlaringiz asosida tuziladi. 30–50 nafar notanish kishilik majburiy guruh yo‘q — kim bilan borishni o‘zingiz tanlaysiz."),
                HomeFAQItem(id: "family", question: "Faqat oilam yoki do‘stlarim bilan bora olamanmi?", answer: "Ha. Paketni bir kishi, juftlik, oila yoki do‘stlar uchun tuzish mumkin. Safarda faqat o‘zingiz qo‘shgan insonlar bo‘ladi."),
                HomeFAQItem(id: "care", question: "Hammasini o‘zim tuzishni istamasam-chi?", answer: "iumrah Care’ga murojaat qiling. Biz variant tanlash, tafsilotlarni tekshirish va safarni rasmiylashtirishga yordam beramiz — majburiy katta guruhsiz.")
            ]
        case .uzbekCyrillic:
            return [
                HomeFAQItem(id: "what", question: "iumrah нима?", answer: "iumrah — мустақил ва шахсий Умра учун платформа. У парвоз, меҳмонхона, трансфер ва хизматларни битта тушунарли пакетга бирлаштиради ва сафарни битта иловада бошқаришга ёрдам беради."),
                HomeFAQItem(id: "why", question: "iumrah нима учун яратилди?", answer: "Зиёратчи катта тур гуруҳига боғланиб қолмаслиги ва кўплаб алоҳида бронларни бошқармаслиги учун. iumrah сафар давомида кўпроқ назорат, шаффофлик ва ғамхўрлик бериш учун яратилган."),
                HomeFAQItem(id: "personal", question: "«Шахсий Умра» нимани англатади?", answer: "Сафар сизнинг саналарингиз, бюджетингиз, меҳмонхона даражаси ва танлаган хизматларингиз асосида тузилади. 30–50 нафар нотаниш кишилик мажбурий гуруҳ йўқ — ким билан боришни ўзингиз танлайсиз."),
                HomeFAQItem(id: "family", question: "Фақат оилам ёки дўстларим билан бора оламанми?", answer: "Ҳа. Пакетни бир киши, жуфтлик, оила ёки дўстлар учун тузиш мумкин. Сафарда фақат ўзингиз қўшган инсонлар бўлади."),
                HomeFAQItem(id: "care", question: "Ҳаммасини ўзим тузишни истамасам-чи?", answer: "iumrah Care’га мурожаат қилинг. Биз вариант танлаш, тафсилотларни текшириш ва сафарни расмийлаштиришга ёрдам берамиз — мажбурий катта гуруҳсиз.")
            ]
        }
    }

    private func money(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.locale = Locale(identifier: settings.language.localeIdentifier)
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: amount)) ?? "$\(Int(amount.rounded()))"
    }
}

private struct HomeFAQItem: Identifiable {
    let id: String
    let question: String
    let answer: String
}
