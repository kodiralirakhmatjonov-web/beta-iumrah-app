import type { D1Like } from "./d1";
import type { Env } from "./env";

type PilgrimRow = {
  id: number;
  first_name?: string | null;
  last_name?: string | null;
  display_name?: string | null;
  phone?: string | null;
  email?: string | null;
  telegram?: string | null;
  whatsapp?: string | null;
};

type AccountAuth = {
  pilgrimID: number;
  tokenHash: string;
  pilgrim: PilgrimRow;
};

type DeviceAuth = AccountAuth & {
  deviceID: string;
  installationID: string;
  sessionID: string;
  isPrimary: boolean;
};

type DeviceInput = {
  installationID: string;
  secret: string;
  name: string;
  model: string;
  platform: string;
  osVersion: string;
  appVersion: string;
  locale: string;
};

type AppleClaims = {
  iss?: string;
  aud?: string | string[];
  exp?: number;
  iat?: number;
  sub?: string;
  nonce?: string;
  email?: string;
  email_verified?: boolean | string;
};

class RouteError extends Error {
  constructor(readonly code: string, readonly status = 400) {
    super(code);
  }
}

const PASSWORD_ITERATIONS = 100_000;
const CODE_ITERATIONS = 100_000;
const SESSION_DAYS = 90;
const CODE_TTL_MINUTES = 10;
const MAX_CODE_ATTEMPTS = 5;
let appleKeyCache: { expiresAt: number; keys: JsonWebKey[] } | null = null;

function json(value: unknown, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

function cleanText(value: unknown, maxLength: number) {
  return String(value ?? "").trim().slice(0, maxLength);
}

function normalizeEmail(value: unknown) {
  return cleanText(value, 254).normalize("NFKC").toLowerCase();
}

function validEmail(value: string) {
  return value.length >= 5
    && value.length <= 254
    && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u.test(value);
}

function validPassword(value: unknown): value is string {
  return typeof value === "string" && value.length >= 8 && value.length <= 128;
}

function constantTimeEqual(left: string, right: string) {
  const a = new TextEncoder().encode(left);
  const b = new TextEncoder().encode(right);
  if (!a.length || a.length !== b.length) return false;
  let difference = 0;
  for (let index = 0; index < a.length; index += 1) difference |= a[index] ^ b[index];
  return difference === 0;
}

function base64URL(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function decodeBase64URL(value: string) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

function randomToken(byteCount = 32) {
  const bytes = new Uint8Array(byteCount);
  crypto.getRandomValues(bytes);
  return base64URL(bytes);
}

function randomVerificationCode() {
  const limit = Math.floor(0x1_0000_0000 / 1_000_000) * 1_000_000;
  const buffer = new Uint32Array(1);
  do crypto.getRandomValues(buffer); while (buffer[0] >= limit);
  return String(buffer[0] % 1_000_000).padStart(6, "0");
}

async function sha256Hex(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function passwordDigest(password: string, salt: string, iterations = PASSWORD_ITERATIONS) {
  if (!Number.isInteger(iterations) || iterations <= 0 || iterations > PASSWORD_ITERATIONS) {
    throw new RouteError("UNSUPPORTED_PASSWORD_ITERATIONS", 409);
  }
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits({
    name: "PBKDF2",
    hash: "SHA-256",
    salt: new TextEncoder().encode(salt),
    iterations,
  }, key, 256);
  return base64URL(new Uint8Array(bits));
}

function bearerToken(request: Request) {
  const authorization = request.headers.get("authorization") ?? "";
  if (!authorization.toLowerCase().startsWith("bearer ")) return "";
  return authorization.slice(7).trim();
}

function accountProfile(pilgrim: PilgrimRow) {
  const firstName = cleanText(pilgrim.first_name, 120);
  const lastName = cleanText(pilgrim.last_name, 120);
  const displayName = cleanText(pilgrim.display_name, 240) || [firstName, lastName].filter(Boolean).join(" ");
  return {
    iumrahID: String(Number(pilgrim.id)).padStart(6, "0"),
    displayName,
    firstName,
    lastName,
    phone: cleanText(pilgrim.phone, 100),
    email: cleanText(pilgrim.email, 254),
    telegram: cleanText(pilgrim.telegram, 120),
    whatsapp: cleanText(pilgrim.whatsapp, 120),
  };
}

async function requireAccount(request: Request, db: D1Like): Promise<AccountAuth> {
  const token = bearerToken(request);
  if (!token || token.length > 256) throw new RouteError("ACCOUNT_SESSION_REQUIRED", 401);
  const tokenHash = await sha256Hex(token);
  const now = new Date().toISOString();
  const row = await db.prepare(
    `SELECT s.pilgrim_id,
            p.id,p.first_name,p.last_name,p.display_name,p.phone,
            p.email,p.telegram,p.whatsapp
     FROM iumrah_account_sessions s
     INNER JOIN pilgrims p ON p.id=s.pilgrim_id
     WHERE s.token_hash=?1 AND s.revoked_at IS NULL AND s.expires_at>?2
     LIMIT 1`,
  ).bind(tokenHash, now).first<PilgrimRow & { pilgrim_id: number }>();
  if (!row) throw new RouteError("ACCOUNT_SESSION_INVALID", 401);
  await db.prepare("UPDATE iumrah_account_sessions SET last_used_at=?1 WHERE token_hash=?2")
    .bind(now, tokenHash).run();
  return { pilgrimID: Number(row.pilgrim_id), tokenHash, pilgrim: row };
}

function requestLocation(request: Request) {
  const cf = (request as Request & { cf?: Record<string, unknown> }).cf ?? {};
  return {
    city: cleanText(cf.city, 100),
    region: cleanText(cf.region, 120),
    country: cleanText(cf.country, 8),
  };
}

function parseDevice(value: unknown): DeviceInput {
  const raw = (value && typeof value === "object" ? value : {}) as Record<string, unknown>;
  const device: DeviceInput = {
    installationID: cleanText(raw.installationID, 80),
    secret: cleanText(raw.secret, 180),
    name: cleanText(raw.name, 120) || "iPhone",
    model: cleanText(raw.model, 100) || "iPhone",
    platform: cleanText(raw.platform, 40) || "iOS",
    osVersion: cleanText(raw.osVersion, 80),
    appVersion: cleanText(raw.appVersion, 80),
    locale: cleanText(raw.locale, 24),
  };
  if (!/^[A-Za-z0-9-]{20,80}$/.test(device.installationID)
      || !/^[A-Za-z0-9_-]{32,180}$/.test(device.secret)) {
    throw new RouteError("INVALID_DEVICE_CREDENTIALS", 400);
  }
  return device;
}

async function bindCurrentSession(
  db: D1Like,
  auth: AccountAuth,
  device: DeviceInput,
  request: Request,
) {
  const now = new Date().toISOString();
  const location = requestLocation(request);
  const secretHash = await sha256Hex(device.secret);
  let deviceRow = await db.prepare(
    `SELECT id,secret_hash FROM iumrah_client_devices
     WHERE pilgrim_id=?1 AND installation_id=?2 LIMIT 1`,
  ).bind(auth.pilgrimID, device.installationID).first<{ id: string; secret_hash: string }>();

  if (deviceRow && !constantTimeEqual(deviceRow.secret_hash, secretHash)) {
    throw new RouteError("DEVICE_ID_CONFLICT", 403);
  }
  if (!deviceRow) {
    const id = `device-${crypto.randomUUID()}`;
    await db.prepare(
      `INSERT INTO iumrah_client_devices(
         id,pilgrim_id,installation_id,secret_hash,name,model,platform,os_version,
         app_version,locale,created_at,first_seen_at,last_seen_at,last_city,last_region,last_country
       ) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?11,?11,?12,?13,?14)`,
    ).bind(
      id, auth.pilgrimID, device.installationID, secretHash, device.name, device.model,
      device.platform, device.osVersion, device.appVersion, device.locale, now,
      location.city, location.region, location.country,
    ).run();
    deviceRow = { id, secret_hash: secretHash };
  } else {
    await db.prepare(
      `UPDATE iumrah_client_devices
       SET name=?1,model=?2,platform=?3,os_version=?4,app_version=?5,locale=?6,
           last_seen_at=?7,last_city=?8,last_region=?9,last_country=?10,revoked_at=NULL
       WHERE id=?11`,
    ).bind(
      device.name, device.model, device.platform, device.osVersion, device.appVersion,
      device.locale, now, location.city, location.region, location.country, deviceRow.id,
    ).run();
  }

  const binding = await db.prepare(
    "SELECT session_id,device_id FROM iumrah_client_session_bindings WHERE token_hash=?1 LIMIT 1",
  ).bind(auth.tokenHash).first<{ session_id: string; device_id: string | null }>();
  if (binding?.device_id && binding.device_id !== deviceRow.id) {
    throw new RouteError("SESSION_ALREADY_BOUND", 409);
  }
  if (binding) {
    await db.prepare(
      `UPDATE iumrah_client_session_bindings
       SET device_id=?1,last_seen_at=?2,last_city=?3,last_region=?4,last_country=?5
       WHERE token_hash=?6`,
    ).bind(deviceRow.id, now, location.city, location.region, location.country, auth.tokenHash).run();
    return binding.session_id;
  }
  const sessionID = `session-${crypto.randomUUID()}`;
  await db.prepare(
    `INSERT INTO iumrah_client_session_bindings(
       session_id,token_hash,pilgrim_id,device_id,created_at,last_seen_at,last_city,last_region,last_country
     ) VALUES(?1,?2,?3,?4,?5,?5,?6,?7,?8)`,
  ).bind(
    sessionID, auth.tokenHash, auth.pilgrimID, deviceRow.id, now,
    location.city, location.region, location.country,
  ).run();
  return sessionID;
}

async function requireDevice(request: Request, db: D1Like): Promise<DeviceAuth> {
  const auth = await requireAccount(request, db);
  const installationID = cleanText(request.headers.get("x-iumrah-device-id"), 80);
  const secret = cleanText(request.headers.get("x-iumrah-device-secret"), 180);
  if (!installationID || !secret) throw new RouteError("DEVICE_REGISTRATION_REQUIRED", 428);
  const secretHash = await sha256Hex(secret);
  const row = await db.prepare(
    `SELECT b.session_id,d.id AS device_id,d.installation_id,d.secret_hash,d.is_primary
     FROM iumrah_client_session_bindings b
     INNER JOIN iumrah_client_devices d ON d.id=b.device_id
     WHERE b.token_hash=?1 AND b.pilgrim_id=?2 AND d.installation_id=?3
       AND d.revoked_at IS NULL
     LIMIT 1`,
  ).bind(auth.tokenHash, auth.pilgrimID, installationID).first<{
    session_id: string;
    device_id: string;
    installation_id: string;
    secret_hash: string;
    is_primary: number;
  }>();
  if (!row || !constantTimeEqual(row.secret_hash, secretHash)) {
    throw new RouteError("DEVICE_AUTHENTICATION_FAILED", 403);
  }
  const now = new Date().toISOString();
  const location = requestLocation(request);
  await db.prepare(
    `UPDATE iumrah_client_devices
     SET last_seen_at=?1,last_city=?2,last_region=?3,last_country=?4 WHERE id=?5`,
  ).bind(now, location.city, location.region, location.country, row.device_id).run();
  await db.prepare(
    `UPDATE iumrah_client_session_bindings
     SET last_seen_at=?1,last_city=?2,last_region=?3,last_country=?4 WHERE session_id=?5`,
  ).bind(now, location.city, location.region, location.country, row.session_id).run();
  return {
    ...auth,
    deviceID: row.device_id,
    installationID: row.installation_id,
    sessionID: row.session_id,
    isPrimary: Number(row.is_primary) === 1,
  };
}

async function ensureLegacySessionHandles(db: D1Like, pilgrimID: number) {
  const now = new Date().toISOString();
  const missing = await db.prepare(
    `SELECT s.token_hash,s.created_at,s.last_used_at
     FROM iumrah_account_sessions s
     LEFT JOIN iumrah_client_session_bindings b ON b.token_hash=s.token_hash
     WHERE s.pilgrim_id=?1 AND s.revoked_at IS NULL AND s.expires_at>?2
       AND b.token_hash IS NULL`,
  ).bind(pilgrimID, now).all<{ token_hash: string; created_at: string; last_used_at: string }>();
  for (const row of missing.results ?? []) {
    await db.prepare(
      `INSERT OR IGNORE INTO iumrah_client_session_bindings(
         session_id,token_hash,pilgrim_id,device_id,created_at,last_seen_at,last_city,last_region,last_country
       ) VALUES(?1,?2,?3,NULL,?4,?5,'','','')`,
    ).bind(
      `session-${crypto.randomUUID()}`, row.token_hash, pilgrimID,
      row.created_at, row.last_used_at || row.created_at,
    ).run();
  }
}

async function securityOverview(db: D1Like, auth: DeviceAuth) {
  await ensureLegacySessionHandles(db, auth.pilgrimID);
  const now = new Date().toISOString();
  const result = await db.prepare(
    `SELECT b.session_id,b.token_hash,s.created_at,s.expires_at,
            COALESCE(s.last_used_at,b.last_seen_at) AS last_active_at,
            b.last_city,b.last_region,b.last_country,
            d.name,d.model,d.platform,d.os_version,d.app_version,d.is_primary
     FROM iumrah_account_sessions s
     INNER JOIN iumrah_client_session_bindings b ON b.token_hash=s.token_hash
     LEFT JOIN iumrah_client_devices d ON d.id=b.device_id AND d.revoked_at IS NULL
     WHERE s.pilgrim_id=?1 AND s.revoked_at IS NULL AND s.expires_at>?2
     ORDER BY CASE WHEN b.token_hash=?3 THEN 0 ELSE 1 END,
              COALESCE(s.last_used_at,b.last_seen_at) DESC`,
  ).bind(auth.pilgrimID, now, auth.tokenHash).all<{
    session_id: string;
    token_hash: string;
    created_at: string;
    expires_at: string;
    last_active_at: string;
    last_city: string;
    last_region: string;
    last_country: string;
    name: string | null;
    model: string | null;
    platform: string | null;
    os_version: string | null;
    app_version: string | null;
    is_primary: number | null;
  }>();
  const sessions = (result.results ?? []).map((row) => {
    const isCurrent = row.token_hash === auth.tokenHash;
    return {
      id: row.session_id,
      deviceName: row.name || "Unknown device",
      model: row.model || "",
      platform: row.platform || "",
      osVersion: row.os_version || "",
      appVersion: row.app_version || "",
      city: row.last_city || "",
      region: row.last_region || "",
      country: row.last_country || "",
      createdAt: row.created_at,
      lastActiveAt: row.last_active_at,
      expiresAt: row.expires_at,
      isCurrent,
      isPrimary: Number(row.is_primary ?? 0) === 1,
      canTerminate: isCurrent || auth.isPrimary,
    };
  });
  const primary = await db.prepare(
    `SELECT id FROM iumrah_client_devices
     WHERE pilgrim_id=?1 AND is_primary=1 AND revoked_at IS NULL LIMIT 1`,
  ).bind(auth.pilgrimID).first<{ id: string }>();
  const apple = await db.prepare(
    "SELECT linked_at FROM iumrah_client_apple_links WHERE pilgrim_id=?1 LIMIT 1",
  ).bind(auth.pilgrimID).first<{ linked_at: string }>();
  const accountEmail = await db.prepare(
    `SELECT email_display,verified_at FROM iumrah_client_account_emails
     WHERE pilgrim_id=?1 LIMIT 1`,
  ).bind(auth.pilgrimID).first<{ email_display: string; verified_at: string }>();
  return {
    ok: true,
    iumrahID: String(auth.pilgrimID).padStart(6, "0"),
    currentSessionID: auth.sessionID,
    currentDeviceIsPrimary: auth.isPrimary,
    primaryDeviceProtected: Boolean(primary),
    loginEmail: accountEmail
      ? { email: accountEmail.email_display, verifiedAt: accountEmail.verified_at }
      : null,
    apple: { linked: Boolean(apple), linkedAt: apple?.linked_at ?? null },
    sessions,
  };
}

async function verifyAccountPassword(db: D1Like, pilgrimID: number, password: string) {
  const row = await db.prepare(
    `SELECT password_salt,password_hash,password_iterations,failed_attempts,locked_until
     FROM iumrah_accounts WHERE pilgrim_id=?1 LIMIT 1`,
  ).bind(pilgrimID).first<{
    password_salt: string;
    password_hash: string;
    password_iterations: number;
    failed_attempts: number;
    locked_until: string | null;
  }>();
  if (!row || !validPassword(password)) throw new RouteError("INVALID_CREDENTIALS", 401);
  if (row.locked_until && Date.parse(row.locked_until) > Date.now()) {
    throw new RouteError("ACCOUNT_TEMPORARILY_LOCKED", 423);
  }
  const expected = await passwordDigest(password, row.password_salt, Number(row.password_iterations));
  if (!constantTimeEqual(expected, row.password_hash)) {
    const attempts = Number(row.failed_attempts ?? 0) + 1;
    const lockedUntil = attempts >= 6 ? new Date(Date.now() + 15 * 60_000).toISOString() : null;
    await db.prepare(
      "UPDATE iumrah_accounts SET failed_attempts=?1,locked_until=?2 WHERE pilgrim_id=?3",
    ).bind(lockedUntil ? 0 : attempts, lockedUntil, pilgrimID).run();
    throw new RouteError(lockedUntil ? "ACCOUNT_TEMPORARILY_LOCKED" : "INVALID_CREDENTIALS", lockedUntil ? 423 : 401);
  }
  await db.prepare(
    "UPDATE iumrah_accounts SET failed_attempts=0,locked_until=NULL WHERE pilgrim_id=?1",
  ).bind(pilgrimID).run();
}

async function audit(
  db: D1Like,
  pilgrimID: number,
  eventType: string,
  actorSessionID: string | null,
  targetSessionID: string | null,
) {
  await db.prepare(
    `INSERT INTO iumrah_client_security_audit(
       id,pilgrim_id,event_type,actor_session_id,target_session_id,created_at
     ) VALUES(?1,?2,?3,?4,?5,?6)`,
  ).bind(
    `audit-${crypto.randomUUID()}`, pilgrimID, eventType, actorSessionID,
    targetSessionID, new Date().toISOString(),
  ).run();
}

async function createAccountSession(db: D1Like, pilgrimID: number) {
  const token = randomToken(32);
  const tokenHash = await sha256Hex(token);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DAYS * 86_400_000).toISOString();
  await db.prepare(
    `INSERT INTO iumrah_account_sessions(token_hash,pilgrim_id,created_at,expires_at,last_used_at)
     VALUES(?1,?2,?3,?4,?3)`,
  ).bind(tokenHash, pilgrimID, now.toISOString(), expiresAt).run();
  return { token, tokenHash, expiresAt };
}

function parseJWT(identityToken: string) {
  const pieces = identityToken.split(".");
  if (pieces.length !== 3) throw new RouteError("APPLE_TOKEN_INVALID", 401);
  try {
    const header = JSON.parse(new TextDecoder().decode(decodeBase64URL(pieces[0]))) as { alg?: string; kid?: string };
    const claims = JSON.parse(new TextDecoder().decode(decodeBase64URL(pieces[1]))) as AppleClaims;
    return { pieces, header, claims };
  } catch {
    throw new RouteError("APPLE_TOKEN_INVALID", 401);
  }
}

async function appleKeys(forceRefresh = false) {
  if (!forceRefresh && appleKeyCache && appleKeyCache.expiresAt > Date.now()) return appleKeyCache.keys;
  const response = await fetch("https://appleid.apple.com/auth/keys", {
    headers: { accept: "application/json" },
  });
  if (!response.ok) throw new RouteError("APPLE_VERIFICATION_UNAVAILABLE", 503);
  const payload = await response.json() as { keys?: JsonWebKey[] };
  if (!Array.isArray(payload.keys) || !payload.keys.length) {
    throw new RouteError("APPLE_VERIFICATION_UNAVAILABLE", 503);
  }
  appleKeyCache = { keys: payload.keys, expiresAt: Date.now() + 6 * 60 * 60_000 };
  return payload.keys;
}

async function verifyAppleIdentity(identityToken: unknown, rawNonce: unknown, bundleID: string) {
  const token = cleanText(identityToken, 12_000);
  const nonce = cleanText(rawNonce, 256);
  if (!token || nonce.length < 32) throw new RouteError("APPLE_TOKEN_INVALID", 401);
  const { pieces, header, claims } = parseJWT(token);
  if (header.alg !== "RS256" || !header.kid) throw new RouteError("APPLE_TOKEN_INVALID", 401);
  let keys = await appleKeys();
  let keyData = keys.find((item) => (item as JsonWebKey & { kid?: string }).kid === header.kid);
  if (!keyData) {
    keys = await appleKeys(true);
    keyData = keys.find((item) => (item as JsonWebKey & { kid?: string }).kid === header.kid);
  }
  if (!keyData) throw new RouteError("APPLE_SIGNING_KEY_NOT_FOUND", 503);
  const key = await crypto.subtle.importKey(
    "jwk",
    keyData,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"],
  );
  const verified = await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    key,
    decodeBase64URL(pieces[2]),
    new TextEncoder().encode(`${pieces[0]}.${pieces[1]}`),
  );
  const now = Math.floor(Date.now() / 1000);
  const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
  if (!verified
      || claims.iss !== "https://appleid.apple.com"
      || !audiences.includes(bundleID)
      || typeof claims.exp !== "number" || claims.exp <= now
      || typeof claims.iat !== "number" || claims.iat > now + 120
      || !claims.sub || claims.sub.length > 255
      || claims.nonce !== await sha256Hex(nonce)) {
    throw new RouteError("APPLE_TOKEN_INVALID", 401);
  }
  return {
    token,
    subject: claims.sub,
    email: normalizeEmail(claims.email),
    emailVerified: claims.email_verified === true || claims.email_verified === "true",
  };
}

async function consumeAppleAssertion(db: D1Like, identityToken: string) {
  const digest = await sha256Hex(identityToken);
  await db.prepare("DELETE FROM iumrah_client_apple_assertions WHERE used_at<?1")
    .bind(new Date(Date.now() - 30 * 86_400_000).toISOString()).run();
  const existing = await db.prepare(
    "SELECT token_hash FROM iumrah_client_apple_assertions WHERE token_hash=?1 LIMIT 1",
  ).bind(digest).first<{ token_hash: string }>();
  if (existing) throw new RouteError("APPLE_TOKEN_REPLAYED", 409);
  await db.prepare(
    "INSERT INTO iumrah_client_apple_assertions(token_hash,used_at) VALUES(?1,?2)",
  ).bind(digest, new Date().toISOString()).run();
}

async function resolveLoginPilgrimID(db: D1Like, identifierValue: unknown) {
  const identifier = cleanText(identifierValue, 254);
  if (/^\d{6}$/.test(identifier)) return Number(identifier);
  const email = normalizeEmail(identifier);
  if (!validEmail(email)) return 0;
  const row = await db.prepare(
    "SELECT pilgrim_id FROM iumrah_client_account_emails WHERE email_normalized=?1 LIMIT 1",
  ).bind(email).first<{ pilgrim_id: number }>();
  return Number(row?.pilgrim_id ?? 0);
}

async function accountRow(db: D1Like, pilgrimID: number) {
  return db.prepare(
    `SELECT p.id,p.first_name,p.last_name,p.display_name,p.phone,p.email,p.telegram,p.whatsapp
     FROM pilgrims p INNER JOIN iumrah_accounts a ON a.pilgrim_id=p.id
     WHERE p.id=?1 LIMIT 1`,
  ).bind(pilgrimID).first<PilgrimRow>();
}

async function loginWithPassword(request: Request, db: D1Like) {
  const payload = await request.json().catch(() => null) as {
    identifier?: unknown;
    iumrahID?: unknown;
    password?: unknown;
    device?: unknown;
  } | null;
  const pilgrimID = await resolveLoginPilgrimID(db, payload?.identifier ?? payload?.iumrahID);
  const password = String(payload?.password ?? "");
  if (!pilgrimID || !validPassword(password)) throw new RouteError("INVALID_CREDENTIALS", 401);
  const pilgrim = await accountRow(db, pilgrimID);
  if (!pilgrim) throw new RouteError("INVALID_CREDENTIALS", 401);
  await verifyAccountPassword(db, pilgrimID, password);
  const device = parseDevice(payload?.device);
  const session = await createAccountSession(db, pilgrimID);
  const auth: AccountAuth = { pilgrimID, tokenHash: session.tokenHash, pilgrim };
  let sessionID: string;
  try {
    sessionID = await bindCurrentSession(db, auth, device, request);
  } catch (error) {
    await db.prepare("UPDATE iumrah_account_sessions SET revoked_at=?1 WHERE token_hash=?2")
      .bind(new Date().toISOString(), session.tokenHash).run();
    throw error;
  }
  const now = new Date().toISOString();
  await db.prepare("UPDATE iumrah_accounts SET last_login_at=?1 WHERE pilgrim_id=?2")
    .bind(now, pilgrimID).run();
  await audit(db, pilgrimID, "password_sign_in", sessionID, sessionID);
  return json({
    ok: true,
    account: accountProfile(pilgrim),
    session: { token: session.token, expiresAt: session.expiresAt },
  });
}

async function linkVerifiedEmail(
  db: D1Like,
  pilgrimID: number,
  emailDisplay: string,
  emailNormalized: string,
) {
  const collision = await db.prepare(
    `SELECT pilgrim_id FROM iumrah_client_account_emails
     WHERE email_normalized=?1 AND pilgrim_id<>?2 LIMIT 1`,
  ).bind(emailNormalized, pilgrimID).first<{ pilgrim_id: number }>();
  if (collision) throw new RouteError("EMAIL_ALREADY_CONNECTED", 409);
  const now = new Date().toISOString();
  await db.prepare(
    `INSERT INTO iumrah_client_account_emails(
       pilgrim_id,email_normalized,email_display,verified_at,updated_at
     ) VALUES(?1,?2,?3,?4,?4)
     ON CONFLICT(pilgrim_id) DO UPDATE SET
       email_normalized=excluded.email_normalized,
       email_display=excluded.email_display,
       verified_at=excluded.verified_at,
       updated_at=excluded.updated_at`,
  ).bind(pilgrimID, emailNormalized, emailDisplay, now).run();
  await db.prepare("UPDATE pilgrims SET email=?1,updated_at=?2 WHERE id=?3")
    .bind(emailDisplay, now, pilgrimID).run();
  await db.prepare(
    `UPDATE iumrah_client_email_challenges SET consumed_at=?1
     WHERE pilgrim_id=?2 AND purpose='verify_email' AND consumed_at IS NULL`,
  ).bind(now, pilgrimID).run();
}

function emailCopy(code: string, purpose: "verify_email" | "reset_password", locale: string) {
  const language = locale.toLowerCase();
  const russian = language.startsWith("ru");
  const uzbek = language.startsWith("uz");
  const title = purpose === "reset_password"
    ? (russian ? "Восстановление пароля iumrah" : uzbek ? "iumrah parolini tiklash" : "Reset your iumrah password")
    : (russian ? "Подтверждение почты iumrah" : uzbek ? "iumrah elektron pochtasini tasdiqlash" : "Verify your iumrah email");
  const lead = purpose === "reset_password"
    ? (russian ? "Код для восстановления пароля:" : uzbek ? "Parolni tiklash kodi:" : "Your password reset code:")
    : (russian ? "Код подтверждения почты:" : uzbek ? "Elektron pochtani tasdiqlash kodi:" : "Your email verification code:");
  const warning = russian
    ? "Код действует 10 минут. Никому его не сообщайте. Если Вы не запрашивали код, проигнорируйте письмо."
    : uzbek
      ? "Kod 10 daqiqa amal qiladi. Uni hech kimga bermang. Agar kodni so‘ramagan bo‘lsangiz, xatni e’tiborsiz qoldiring."
      : "This code expires in 10 minutes. Never share it. If you did not request it, ignore this email.";
  return {
    subject: title,
    text: `${lead}\n\n${code}\n\n${warning}`,
    html: `<!doctype html><html><body style="margin:0;background:#f5f5f7;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:#111"><div style="max-width:520px;margin:32px auto;background:#fff;border-radius:28px;padding:32px"><div style="font-size:18px;font-weight:700">iumrah</div><h1 style="font-size:26px;margin:28px 0 12px">${title}</h1><p style="color:#62676d;line-height:1.5">${lead}</p><div style="font-size:36px;font-weight:750;letter-spacing:9px;padding:18px 0">${code}</div><p style="color:#62676d;line-height:1.5">${warning}</p></div></body></html>`,
  };
}

async function sendAccountEmail(
  env: Env,
  to: string,
  copy: { subject: string; text: string; html: string },
) {
  const apiKey = cleanText(env.RESEND_API_KEY, 300);
  if (!apiKey) throw new RouteError("EMAIL_DELIVERY_NOT_CONFIGURED", 503);
  const fromAddress = cleanText(env.ACCOUNT_EMAIL_FROM, 254) || "security@iumrah.app";
  const replyTo = cleanText(env.ACCOUNT_EMAIL_REPLY_TO, 254) || "support@iumrah.app";
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      authorization: `Bearer ${apiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      from: `iumrah <${fromAddress}>`,
      to: [to],
      reply_to: replyTo,
      subject: copy.subject,
      text: copy.text,
      html: copy.html,
    }),
  });
  if (!response.ok) {
    console.error("RESEND_ACCOUNT_EMAIL_FAILED", response.status, await response.text().catch(() => ""));
    throw new RouteError("EMAIL_DELIVERY_UNAVAILABLE", 503);
  }
}

async function challengeRate(db: D1Like, purpose: string, email: string, pilgrimID: number | null, request: Request) {
  const since = new Date(Date.now() - 60 * 60_000).toISOString();
  const ip = cleanText(request.headers.get("cf-connecting-ip"), 80);
  const ipHash = ip ? await sha256Hex(ip) : "";
  const row = await db.prepare(
    `SELECT COUNT(*) AS count FROM iumrah_client_email_challenges
     WHERE purpose=?1 AND created_at>?2
       AND (email_normalized=?3 OR (?4<>'' AND request_ip_hash=?4)
            OR (?5 IS NOT NULL AND pilgrim_id=?5))`,
  ).bind(purpose, since, email, ipHash, pilgrimID).first<{ count: number }>();
  return { limited: Number(row?.count ?? 0) >= 5, ipHash };
}

async function createEmailChallenge(
  db: D1Like,
  env: Env,
  request: Request,
  purpose: "verify_email" | "reset_password",
  pilgrimID: number,
  emailDisplay: string,
  locale: string,
) {
  const emailNormalized = normalizeEmail(emailDisplay);
  if (!validEmail(emailNormalized)) throw new RouteError("EMAIL_INVALID", 400);
  const rate = await challengeRate(db, purpose, emailNormalized, pilgrimID, request);
  if (rate.limited) throw new RouteError("EMAIL_RATE_LIMITED", 429);
  const code = randomVerificationCode();
  const salt = randomToken(18);
  const codeHash = await passwordDigest(code, salt, CODE_ITERATIONS);
  const id = `challenge-${crypto.randomUUID()}`;
  const now = new Date();
  const expiresAt = new Date(now.getTime() + CODE_TTL_MINUTES * 60_000).toISOString();
  await db.prepare(
    `INSERT INTO iumrah_client_email_challenges(
       id,purpose,pilgrim_id,email_normalized,email_display,code_salt,code_hash,
       code_iterations,attempts,max_attempts,expires_at,created_at,request_ip_hash
     ) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,0,?9,?10,?11,?12)`,
  ).bind(
    id, purpose, pilgrimID, emailNormalized, emailDisplay, salt, codeHash,
    CODE_ITERATIONS, MAX_CODE_ATTEMPTS, expiresAt, now.toISOString(), rate.ipHash,
  ).run();
  try {
    await sendAccountEmail(env, emailDisplay, emailCopy(code, purpose, locale));
  } catch (error) {
    await db.prepare("UPDATE iumrah_client_email_challenges SET consumed_at=?1 WHERE id=?2")
      .bind(new Date().toISOString(), id).run();
    throw error;
  }
  return { id, expiresAt };
}

async function verifyEmailChallenge(
  db: D1Like,
  challengeID: string,
  purpose: "verify_email" | "reset_password",
  code: string,
  pilgrimID?: number,
) {
  const row = await db.prepare(
    `SELECT id,pilgrim_id,email_normalized,email_display,code_salt,code_hash,
            code_iterations,attempts,max_attempts,expires_at,consumed_at
     FROM iumrah_client_email_challenges WHERE id=?1 AND purpose=?2 LIMIT 1`,
  ).bind(challengeID, purpose).first<{
    id: string;
    pilgrim_id: number;
    email_normalized: string;
    email_display: string;
    code_salt: string;
    code_hash: string;
    code_iterations: number;
    attempts: number;
    max_attempts: number;
    expires_at: string;
    consumed_at: string | null;
  }>();
  if (!row || row.consumed_at || Date.parse(row.expires_at) <= Date.now()
      || (pilgrimID !== undefined && Number(row.pilgrim_id) !== pilgrimID)
      || !/^\d{6}$/.test(code) || Number(row.attempts) >= Number(row.max_attempts)) {
    throw new RouteError("VERIFICATION_CODE_INVALID", 400);
  }
  const digest = await passwordDigest(code, row.code_salt, Number(row.code_iterations));
  if (!constantTimeEqual(digest, row.code_hash)) {
    const attempts = Number(row.attempts) + 1;
    await db.prepare(
      `UPDATE iumrah_client_email_challenges
       SET attempts=?1,consumed_at=CASE WHEN ?1>=max_attempts THEN ?2 ELSE consumed_at END
       WHERE id=?3`,
    ).bind(attempts, new Date().toISOString(), row.id).run();
    throw new RouteError("VERIFICATION_CODE_INVALID", 400);
  }
  await db.prepare("UPDATE iumrah_client_email_challenges SET consumed_at=?1 WHERE id=?2")
    .bind(new Date().toISOString(), row.id).run();
  return row;
}

async function register(request: Request, db: D1Like) {
  const auth = await requireAccount(request, db);
  const payload = await request.json().catch(() => null) as { device?: unknown } | null;
  const device = parseDevice(payload?.device);
  await bindCurrentSession(db, auth, device, request);
  const headers = new Headers(request.headers);
  headers.set("x-iumrah-device-id", device.installationID);
  headers.set("x-iumrah-device-secret", device.secret);
  const secured = await requireDevice(new Request(request.url, { method: "GET", headers }), db);
  return json(await securityOverview(db, secured));
}

async function claimPrimary(request: Request, db: D1Like) {
  const auth = await requireDevice(request, db);
  const payload = await request.json().catch(() => null) as { password?: unknown } | null;
  await verifyAccountPassword(db, auth.pilgrimID, String(payload?.password ?? ""));
  const existing = await db.prepare(
    `SELECT id FROM iumrah_client_devices
     WHERE pilgrim_id=?1 AND is_primary=1 AND revoked_at IS NULL LIMIT 1`,
  ).bind(auth.pilgrimID).first<{ id: string }>();
  if (existing && existing.id !== auth.deviceID) {
    throw new RouteError("PRIMARY_DEVICE_ALREADY_PROTECTED", 409);
  }
  await db.prepare(
    `UPDATE iumrah_client_devices
     SET is_primary=CASE WHEN id=?1 THEN 1 ELSE 0 END WHERE pilgrim_id=?2`,
  ).bind(auth.deviceID, auth.pilgrimID).run();
  await audit(db, auth.pilgrimID, "primary_device_claimed", auth.sessionID, auth.sessionID);
  return json(await securityOverview(db, { ...auth, isPrimary: true }));
}

async function terminateSession(request: Request, db: D1Like, sessionID: string) {
  const auth = await requireDevice(request, db);
  const target = await db.prepare(
    `SELECT b.token_hash,b.session_id
     FROM iumrah_client_session_bindings b
     INNER JOIN iumrah_account_sessions s ON s.token_hash=b.token_hash
     WHERE b.session_id=?1 AND b.pilgrim_id=?2
       AND s.revoked_at IS NULL AND s.expires_at>?3 LIMIT 1`,
  ).bind(sessionID, auth.pilgrimID, new Date().toISOString()).first<{
    token_hash: string;
    session_id: string;
  }>();
  if (!target) throw new RouteError("SESSION_NOT_FOUND", 404);
  const self = target.token_hash === auth.tokenHash;
  if (!self && !auth.isPrimary) throw new RouteError("PRIMARY_DEVICE_REQUIRED", 403);
  await db.prepare("UPDATE iumrah_account_sessions SET revoked_at=?1 WHERE token_hash=?2")
    .bind(new Date().toISOString(), target.token_hash).run();
  await audit(db, auth.pilgrimID, "session_terminated", auth.sessionID, target.session_id);
  return json({ ok: true, signedOut: self });
}

async function startEmailVerification(request: Request, env: Env, db: D1Like) {
  const auth = await requireDevice(request, db);
  if (!auth.isPrimary) throw new RouteError("PRIMARY_DEVICE_REQUIRED", 403);
  const payload = await request.json().catch(() => null) as { email?: unknown; locale?: unknown } | null;
  const email = cleanText(payload?.email, 254);
  const normalized = normalizeEmail(email);
  if (!validEmail(normalized)) throw new RouteError("EMAIL_INVALID", 400);
  const challenge = await createEmailChallenge(
    db, env, request, "verify_email", auth.pilgrimID, email, cleanText(payload?.locale, 24),
  );
  await audit(db, auth.pilgrimID, "email_verification_started", auth.sessionID, null);
  return json({ ok: true, challengeID: challenge.id, expiresAt: challenge.expiresAt });
}

async function confirmEmailVerification(request: Request, db: D1Like) {
  const auth = await requireDevice(request, db);
  if (!auth.isPrimary) throw new RouteError("PRIMARY_DEVICE_REQUIRED", 403);
  const payload = await request.json().catch(() => null) as { challengeID?: unknown; code?: unknown } | null;
  const challenge = await verifyEmailChallenge(
    db,
    cleanText(payload?.challengeID, 100),
    "verify_email",
    cleanText(payload?.code, 12),
    auth.pilgrimID,
  );
  await linkVerifiedEmail(db, auth.pilgrimID, challenge.email_display, challenge.email_normalized);
  await audit(db, auth.pilgrimID, "login_email_verified", auth.sessionID, null);
  return json({ ok: true, email: challenge.email_display, verifiedAt: new Date().toISOString() });
}

async function startPasswordRecovery(request: Request, env: Env, db: D1Like) {
  if (!cleanText(env.RESEND_API_KEY, 300)) {
    throw new RouteError("EMAIL_DELIVERY_NOT_CONFIGURED", 503);
  }
  const payload = await request.json().catch(() => null) as { email?: unknown; locale?: unknown } | null;
  const email = normalizeEmail(payload?.email);
  const publicChallengeID = `challenge-${crypto.randomUUID()}`;
  if (!validEmail(email)) return json({ ok: true, challengeID: publicChallengeID });
  const accountEmail = await db.prepare(
    `SELECT pilgrim_id,email_display FROM iumrah_client_account_emails
     WHERE email_normalized=?1 LIMIT 1`,
  ).bind(email).first<{ pilgrim_id: number; email_display: string }>();
  if (!accountEmail) return json({ ok: true, challengeID: publicChallengeID });
  // A known, verified account must never receive a fake success when Resend
  // rejected the message. Propagate delivery/configuration failures so the app
  // stays on the email form and tells the user to retry instead of opening an
  // unusable code screen. Unknown addresses still get the neutral response
  // above to avoid exposing whether an account exists.
  const challenge = await createEmailChallenge(
    db, env, request, "reset_password", Number(accountEmail.pilgrim_id),
    accountEmail.email_display, cleanText(payload?.locale, 24),
  );
  await audit(db, Number(accountEmail.pilgrim_id), "password_reset_started", null, null);
  return json({ ok: true, challengeID: challenge.id, expiresAt: challenge.expiresAt });
}

async function confirmPasswordRecovery(request: Request, db: D1Like) {
  const payload = await request.json().catch(() => null) as {
    challengeID?: unknown;
    code?: unknown;
    newPassword?: unknown;
  } | null;
  if (!validPassword(payload?.newPassword)) throw new RouteError("PASSWORD_TOO_WEAK", 400);
  const challenge = await verifyEmailChallenge(
    db,
    cleanText(payload?.challengeID, 100),
    "reset_password",
    cleanText(payload?.code, 12),
  );
  const salt = randomToken(18);
  const passwordHash = await passwordDigest(payload.newPassword, salt, PASSWORD_ITERATIONS);
  const now = new Date().toISOString();
  await db.prepare(
    `UPDATE iumrah_accounts
     SET password_salt=?1,password_hash=?2,password_iterations=?3,password_updated_at=?4,
         failed_attempts=0,locked_until=NULL
     WHERE pilgrim_id=?5`,
  ).bind(salt, passwordHash, PASSWORD_ITERATIONS, now, Number(challenge.pilgrim_id)).run();
  await db.prepare(
    "UPDATE iumrah_account_sessions SET revoked_at=?1 WHERE pilgrim_id=?2 AND revoked_at IS NULL",
  ).bind(now, Number(challenge.pilgrim_id)).run();
  await db.prepare(
    "UPDATE iumrah_client_devices SET is_primary=0 WHERE pilgrim_id=?1",
  ).bind(Number(challenge.pilgrim_id)).run();
  await audit(db, Number(challenge.pilgrim_id), "password_reset_completed", null, null);
  return json({
    ok: true,
    iumrahID: String(Number(challenge.pilgrim_id)).padStart(6, "0"),
    sessionsRevoked: true,
  });
}

async function linkApple(request: Request, env: Env, db: D1Like) {
  const auth = await requireDevice(request, db);
  if (!auth.isPrimary) throw new RouteError("PRIMARY_DEVICE_REQUIRED", 403);
  const payload = await request.json().catch(() => null) as {
    identityToken?: unknown;
    nonce?: unknown;
  } | null;
  const apple = await verifyAppleIdentity(
    payload?.identityToken,
    payload?.nonce,
    env.APPLE_BUNDLE_ID ?? "com.iumrah.beta",
  );
  await consumeAppleAssertion(db, apple.token);
  const subjectOwner = await db.prepare(
    "SELECT pilgrim_id FROM iumrah_client_apple_links WHERE apple_subject=?1 LIMIT 1",
  ).bind(apple.subject).first<{ pilgrim_id: number }>();
  if (subjectOwner && Number(subjectOwner.pilgrim_id) !== auth.pilgrimID) {
    throw new RouteError("APPLE_ID_CONNECTED_TO_ANOTHER_ACCOUNT", 409);
  }
  const accountLink = await db.prepare(
    "SELECT apple_subject FROM iumrah_client_apple_links WHERE pilgrim_id=?1 LIMIT 1",
  ).bind(auth.pilgrimID).first<{ apple_subject: string }>();
  if (accountLink && accountLink.apple_subject !== apple.subject) {
    throw new RouteError("APPLE_ID_ALREADY_CONNECTED", 409);
  }
  const now = new Date().toISOString();
  await db.prepare(
    `INSERT INTO iumrah_client_apple_links(apple_subject,pilgrim_id,linked_at,last_used_at)
     VALUES(?1,?2,?3,?3)
     ON CONFLICT(apple_subject) DO UPDATE SET last_used_at=excluded.last_used_at`,
  ).bind(apple.subject, auth.pilgrimID, now).run();
  if (apple.emailVerified && validEmail(apple.email)) {
    const emailOwner = await db.prepare(
      "SELECT pilgrim_id FROM iumrah_client_account_emails WHERE email_normalized=?1 LIMIT 1",
    ).bind(apple.email).first<{ pilgrim_id: number }>();
    if (emailOwner && Number(emailOwner.pilgrim_id) !== auth.pilgrimID) {
      await db.prepare("DELETE FROM iumrah_client_apple_links WHERE apple_subject=?1")
        .bind(apple.subject).run();
      throw new RouteError("APPLE_EMAIL_CONNECTED_TO_ANOTHER_ACCOUNT", 409);
    }
    const currentEmail = await db.prepare(
      "SELECT pilgrim_id FROM iumrah_client_account_emails WHERE pilgrim_id=?1 LIMIT 1",
    ).bind(auth.pilgrimID).first<{ pilgrim_id: number }>();
    if (!currentEmail) await linkVerifiedEmail(db, auth.pilgrimID, apple.email, apple.email);
  }
  await audit(db, auth.pilgrimID, "apple_id_linked", auth.sessionID, auth.sessionID);
  return json({ ok: true, appleLinked: true, iumrahID: String(auth.pilgrimID).padStart(6, "0") });
}

async function signInWithApple(request: Request, env: Env, db: D1Like) {
  const payload = await request.json().catch(() => null) as {
    identityToken?: unknown;
    nonce?: unknown;
    device?: unknown;
  } | null;
  const apple = await verifyAppleIdentity(
    payload?.identityToken,
    payload?.nonce,
    env.APPLE_BUNDLE_ID ?? "com.iumrah.beta",
  );
  await consumeAppleAssertion(db, apple.token);
  let row = await db.prepare(
    `SELECT p.id,p.first_name,p.last_name,p.display_name,p.phone,p.email,p.telegram,p.whatsapp
     FROM iumrah_client_apple_links a
     INNER JOIN pilgrims p ON p.id=a.pilgrim_id
     INNER JOIN iumrah_accounts account ON account.pilgrim_id=p.id
     WHERE a.apple_subject=?1 LIMIT 1`,
  ).bind(apple.subject).first<PilgrimRow>();
  let createdAccount = false;
  if (!row) {
    if (!apple.emailVerified || !validEmail(apple.email)) {
      throw new RouteError("APPLE_ACCOUNT_EMAIL_REQUIRED", 409);
    }
    const existingEmail = await db.prepare(
      `SELECT p.id,p.first_name,p.last_name,p.display_name,p.phone,p.email,p.telegram,p.whatsapp
       FROM iumrah_client_account_emails e
       INNER JOIN pilgrims p ON p.id=e.pilgrim_id
       INNER JOIN iumrah_accounts a ON a.pilgrim_id=p.id
       WHERE e.email_normalized=?1 LIMIT 1`,
    ).bind(apple.email).first<PilgrimRow>();
    if (existingEmail) {
      row = existingEmail;
    } else {
      const now = new Date().toISOString();
      const created = await db.prepare(
        `INSERT INTO pilgrims(email,created_at,updated_at)
         VALUES(?1,?2,?2)
         RETURNING id,first_name,last_name,display_name,phone,email,telegram,whatsapp`,
      ).bind(apple.email, now).first<PilgrimRow>();
      if (!created) throw new RouteError("APPLE_ACCOUNT_CREATION_FAILED", 503);
      try {
        await linkVerifiedEmail(db, Number(created.id), apple.email, apple.email);
        const salt = randomToken(18);
        const inaccessiblePassword = randomToken(48);
        const passwordHash = await passwordDigest(inaccessiblePassword, salt, PASSWORD_ITERATIONS);
        await db.prepare(
          `INSERT INTO iumrah_accounts(
             pilgrim_id,password_salt,password_hash,password_iterations,activated_at,password_updated_at
           ) VALUES(?1,?2,?3,?4,?5,?5)`,
        ).bind(Number(created.id), salt, passwordHash, PASSWORD_ITERATIONS, now).run();
        row = created;
        createdAccount = true;
      } catch (error) {
        await db.prepare("DELETE FROM pilgrims WHERE id=?1").bind(Number(created.id)).run().catch(() => undefined);
        const racedOwner = await db.prepare(
          `SELECT p.id,p.first_name,p.last_name,p.display_name,p.phone,p.email,p.telegram,p.whatsapp
           FROM iumrah_client_account_emails e
           INNER JOIN pilgrims p ON p.id=e.pilgrim_id
           INNER JOIN iumrah_accounts a ON a.pilgrim_id=p.id
           WHERE e.email_normalized=?1 LIMIT 1`,
        ).bind(apple.email).first<PilgrimRow>();
        if (!racedOwner) throw error;
        row = racedOwner;
      }
    }
    try {
      const now = new Date().toISOString();
      await db.prepare(
        `INSERT INTO iumrah_client_apple_links(apple_subject,pilgrim_id,linked_at,last_used_at)
         VALUES(?1,?2,?3,?3)`,
      ).bind(apple.subject, Number(row.id), now).run();
    } catch (error) {
      const linkedOwner = await db.prepare(
        `SELECT p.id,p.first_name,p.last_name,p.display_name,p.phone,p.email,p.telegram,p.whatsapp
         FROM iumrah_client_apple_links a
         INNER JOIN pilgrims p ON p.id=a.pilgrim_id
         WHERE a.apple_subject=?1 LIMIT 1`,
      ).bind(apple.subject).first<PilgrimRow>();
      if (!linkedOwner) throw error;
      row = linkedOwner;
      createdAccount = false;
    }
  }
  const device = parseDevice(payload?.device);
  const session = await createAccountSession(db, Number(row.id));
  const auth: AccountAuth = { pilgrimID: Number(row.id), tokenHash: session.tokenHash, pilgrim: row };
  let sessionID: string;
  try {
    sessionID = await bindCurrentSession(db, auth, device, request);
  } catch (error) {
    await db.prepare("UPDATE iumrah_account_sessions SET revoked_at=?1 WHERE token_hash=?2")
      .bind(new Date().toISOString(), session.tokenHash).run();
    throw error;
  }
  if (createdAccount) {
    await db.prepare(
      `UPDATE iumrah_client_devices SET is_primary=1
       WHERE pilgrim_id=?1 AND installation_id=?2`,
    ).bind(Number(row.id), device.installationID).run();
  }
  const now = new Date().toISOString();
  await db.prepare("UPDATE iumrah_client_apple_links SET last_used_at=?1 WHERE apple_subject=?2")
    .bind(now, apple.subject).run();
  await db.prepare("UPDATE iumrah_accounts SET last_login_at=?1 WHERE pilgrim_id=?2")
    .bind(now, Number(row.id)).run();
  await audit(db, Number(row.id), createdAccount ? "apple_account_created" : "apple_sign_in", sessionID, sessionID);
  return json({
    ok: true,
    account: accountProfile(row),
    session: { token: session.token, expiresAt: session.expiresAt },
  });
}


function friendGiftCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(9);
  crypto.getRandomValues(bytes);
  let value = "";
  for (const byte of bytes) value += alphabet[byte % alphabet.length];
  return `IUMG-${value}`;
}

async function ensureFriendGifts(db: D1Like, pilgrimID: number) {
  const existing = await db.prepare(
    `SELECT position FROM iumrah_friends_gifts
     WHERE referrer_pilgrim_id=?1 ORDER BY position ASC`,
  ).bind(pilgrimID).all<{ position: number }>();
  const positions = new Set((existing.results ?? []).map((row) => Number(row.position)));
  const now = new Date().toISOString();

  for (let position = 1; position <= 3; position += 1) {
    if (positions.has(position)) continue;
    let inserted = false;
    for (let attempt = 0; attempt < 5 && !inserted; attempt += 1) {
      try {
        await db.prepare(
          `INSERT INTO iumrah_friends_gifts(
             id,gift_token,referrer_pilgrim_id,position,status,created_at
           ) VALUES(?1,?2,?3,?4,'available',?5)`,
        ).bind(`gift-${crypto.randomUUID()}`, friendGiftCode(), pilgrimID, position, now).run();
        inserted = true;
      } catch (error) {
        if (attempt === 4) throw error;
      }
    }
  }
}

function normalizedBookingSettlementStatus(value: unknown) {
  return cleanText(value, 80).replace(/-/g, "_").toUpperCase();
}

async function internalBookingStatus(env: Env, bookingID: string) {
  if (!env.BOOKINGS_DB) return "";
  try {
    const row = await env.BOOKINGS_DB.prepare(
      "SELECT status,payload_json FROM bookings WHERE id=?1 LIMIT 1",
    ).bind(bookingID).first<{ status?: string | null; payload_json?: string | null }>();
    if (!row) return "";
    const direct = normalizedBookingSettlementStatus(row.status);
    if (direct) return direct;
    try {
      const payload = JSON.parse(row.payload_json ?? "{}") as Record<string, unknown>;
      return normalizedBookingSettlementStatus(payload.status);
    } catch {
      return "";
    }
  } catch {
    try {
      const row = await env.BOOKINGS_DB.prepare(
        "SELECT payload_json FROM bookings WHERE id=?1 LIMIT 1",
      ).bind(bookingID).first<{ payload_json?: string | null }>();
      if (!row) return "";
      const payload = JSON.parse(row.payload_json ?? "{}") as Record<string, unknown>;
      return normalizedBookingSettlementStatus(payload.status);
    } catch {
      return "";
    }
  }
}

async function settleFriendRewards(env: Env, referrerPilgrimID: number) {
  if (!env.HOTELS_DB || !env.BOOKINGS_DB) return;
  const pending = await env.HOTELS_DB.prepare(
    `SELECT r.id,r.gift_id,r.booking_id,r.reward_usd
     FROM iumrah_friends_redemptions r
     WHERE r.referrer_pilgrim_id=?1 AND r.reward_status='pending'
     ORDER BY r.created_at ASC LIMIT 40`,
  ).bind(referrerPilgrimID).all<{
    id: string;
    gift_id: string;
    booking_id: string;
    reward_usd: number;
  }>();

  for (const row of pending.results ?? []) {
    const status = await internalBookingStatus(env, row.booking_id);
    const paid = ["PAID", "BOOKING_CONFIRMED", "DOCUMENTS_READY", "READY_TO_TRAVEL", "IN_TRIP", "COMPLETED"].includes(status);
    const cancelled = status === "CANCELLED";
    if (!paid && !cancelled) continue;

    const now = new Date().toISOString();
    if (paid) {
      await env.HOTELS_DB.prepare(
        `UPDATE iumrah_friends_redemptions
         SET status='earned',reward_status='earned',settled_at=?1
         WHERE id=?2 AND reward_status='pending'`,
      ).bind(now, row.id).run();
      await env.HOTELS_DB.prepare(
        `INSERT OR IGNORE INTO iumrah_friends_credit_ledger(
           id,pilgrim_id,amount_usd,source_type,source_id,booking_id,created_at
         ) VALUES(?1,?2,?3,'friend_paid',?4,?5,?6)`,
      ).bind(
        `credit-${crypto.randomUUID()}`,
        referrerPilgrimID,
        Number(row.reward_usd || 100),
        row.id,
        row.booking_id,
        now,
      ).run();
    } else {
      await env.HOTELS_DB.prepare(
        `UPDATE iumrah_friends_redemptions
         SET status='cancelled',reward_status='cancelled',settled_at=?1
         WHERE id=?2 AND reward_status='pending'`,
      ).bind(now, row.id).run();
      await env.HOTELS_DB.prepare(
        `UPDATE iumrah_friends_gifts
         SET status='available',redeemed_booking_id=NULL,redeemed_at=NULL
         WHERE id=?1`,
      ).bind(row.gift_id).run();
    }
  }

  // A reward is earned only while the referred paid booking remains valid.
  // If Business later cancels/refunds that trip, reverse the iumrah Credit and
  // release the Gift Card again. The ledger makes the reversal idempotent.
  const earned = await env.HOTELS_DB.prepare(
    `SELECT r.id,r.gift_id,r.booking_id,r.reward_usd
     FROM iumrah_friends_redemptions r
     WHERE r.referrer_pilgrim_id=?1 AND r.reward_status='earned'
     ORDER BY r.settled_at DESC LIMIT 40`,
  ).bind(referrerPilgrimID).all<{
    id: string;
    gift_id: string;
    booking_id: string;
    reward_usd: number;
  }>();

  for (const row of earned.results ?? []) {
    const status = await internalBookingStatus(env, row.booking_id);
    if (status !== "CANCELLED") continue;
    const now = new Date().toISOString();
    await env.HOTELS_DB.prepare(
      `UPDATE iumrah_friends_redemptions
       SET status='cancelled',reward_status='cancelled',settled_at=?1
       WHERE id=?2 AND reward_status='earned'`,
    ).bind(now, row.id).run();
    await env.HOTELS_DB.prepare(
      `INSERT OR IGNORE INTO iumrah_friends_credit_ledger(
         id,pilgrim_id,amount_usd,source_type,source_id,booking_id,created_at
       ) VALUES(?1,?2,?3,'friend_cancelled_reversal',?4,?5,?6)`,
    ).bind(
      `credit-${crypto.randomUUID()}`,
      referrerPilgrimID,
      -Math.abs(Number(row.reward_usd || 100)),
      row.id,
      row.booking_id,
      now,
    ).run();
    await env.HOTELS_DB.prepare(
      `UPDATE iumrah_friends_gifts
       SET status='available',redeemed_booking_id=NULL,redeemed_at=NULL
       WHERE id=?1`,
    ).bind(row.gift_id).run();
  }
}

async function friendCreditBalance(db: D1Like, pilgrimID: number) {
  const row = await db.prepare(
    `SELECT COALESCE(SUM(amount_usd),0) AS balance
     FROM iumrah_friends_credit_ledger WHERE pilgrim_id=?1`,
  ).bind(pilgrimID).first<{ balance: number | string }>();
  return Math.max(0, Number(row?.balance ?? 0));
}

async function friendsDashboard(request: Request, env: Env, db: D1Like) {
  const auth = await requireDevice(request, db);
  await ensureFriendGifts(db, auth.pilgrimID);
  await settleFriendRewards(env, auth.pilgrimID);

  const gifts = await db.prepare(
    `SELECT g.id,g.gift_token,g.position,g.status,g.redeemed_booking_id,g.created_at,g.redeemed_at,
            r.reward_status,r.reward_usd,r.discount_usd
     FROM iumrah_friends_gifts g
     LEFT JOIN iumrah_friends_redemptions r ON r.gift_id=g.id AND r.status<>'cancelled'
     WHERE g.referrer_pilgrim_id=?1
     ORDER BY g.position ASC`,
  ).bind(auth.pilgrimID).all<{
    id: string;
    gift_token: string;
    position: number;
    status: string;
    redeemed_booking_id: string | null;
    created_at: string;
    redeemed_at: string | null;
    reward_status: string | null;
    reward_usd: number | null;
    discount_usd: number | null;
  }>();

  const balance = await friendCreditBalance(db, auth.pilgrimID);
  const pending = await db.prepare(
    `SELECT COALESCE(SUM(reward_usd),0) AS amount
     FROM iumrah_friends_redemptions
     WHERE referrer_pilgrim_id=?1 AND reward_status='pending'`,
  ).bind(auth.pilgrimID).first<{ amount: number | string }>();
  const earned = await db.prepare(
    `SELECT COALESCE(SUM(reward_usd),0) AS amount
     FROM iumrah_friends_redemptions
     WHERE referrer_pilgrim_id=?1 AND reward_status='earned'`,
  ).bind(auth.pilgrimID).first<{ amount: number | string }>();

  return json({
    ok: true,
    availableCreditUsd: balance,
    pendingRewardsUsd: Number(pending?.amount ?? 0),
    earnedRewardsUsd: Number(earned?.amount ?? 0),
    gifts: (gifts.results ?? []).map((gift) => ({
      id: gift.id,
      code: gift.gift_token,
      position: Number(gift.position),
      status: gift.status,
      redeemedBookingID: gift.redeemed_booking_id,
      rewardStatus: gift.reward_status ?? null,
      rewardUsd: Number(gift.reward_usd ?? 100),
      discountUsd: Number(gift.discount_usd ?? 100),
      createdAt: gift.created_at,
      redeemedAt: gift.redeemed_at,
    })),
  });
}

export async function handleClientAccountSecurity(request: Request, env: Env, url: URL) {
  if (!env.HOTELS_DB) return json({ ok: false, error: "HOTELS_DB_NOT_CONFIGURED" }, 503);
  const db = env.HOTELS_DB;
  try {
    if (request.method === "POST" && url.pathname === "/api/package/client/account/login") {
      return await loginWithPassword(request, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/security/register") {
      return await register(request, db);
    }
    if (request.method === "GET" && url.pathname === "/api/package/client/account/friends") {
      return await friendsDashboard(request, env, db);
    }
    if (request.method === "GET" && url.pathname === "/api/package/client/account/security") {
      const auth = await requireDevice(request, db);
      return json(await securityOverview(db, auth));
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/security/claim-primary") {
      return await claimPrimary(request, db);
    }
    const sessionMatch = url.pathname.match(/^\/api\/package\/client\/account\/security\/sessions\/([^/]+)$/);
    if (request.method === "DELETE" && sessionMatch) {
      return await terminateSession(request, db, decodeURIComponent(sessionMatch[1]));
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/apple/link") {
      return await linkApple(request, env, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/apple/sign-in") {
      return await signInWithApple(request, env, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/email/start") {
      return await startEmailVerification(request, env, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/email/confirm") {
      return await confirmEmailVerification(request, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/password/recovery/start") {
      return await startPasswordRecovery(request, env, db);
    }
    if (request.method === "POST" && url.pathname === "/api/package/client/account/password/recovery/confirm") {
      return await confirmPasswordRecovery(request, db);
    }
    return json({ ok: false, error: "NOT_FOUND" }, 404);
  } catch (error) {
    if (error instanceof RouteError) return json({ ok: false, error: error.code }, error.status);
    console.error("CLIENT_ACCOUNT_SECURITY_FAILED", error);
    return json({ ok: false, error: "ACCOUNT_SECURITY_UNAVAILABLE" }, 500);
  }
}
