# kepler-mobile

Public codename repository for the new iumrah client mobile application.

## Stack

- React Native 0.87
- React 19
- TypeScript
- Native iOS and Android projects
- GitHub Actions for validation and test builds

No production secrets, Gemini keys, Cloudflare credentials, pricing logic, or private customer data belong in this repository.
